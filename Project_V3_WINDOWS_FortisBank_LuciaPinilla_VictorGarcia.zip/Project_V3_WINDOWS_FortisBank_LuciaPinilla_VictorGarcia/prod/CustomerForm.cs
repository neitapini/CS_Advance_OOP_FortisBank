﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.bus;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia
{
    public partial class CustomerForm : Form
    {
        DataAccess myCollections = new DataAccess();
        DataAccess myCollectionsFromFile = new DataAccess();

        FortisBank theBank = new FortisBank();

        int index;

        //static String binFilepath = @"../../data/listCustomers.bin";
        static String binFilepathAcc = @"../../data/listAccounts.bin";
        static String binFilepathTrans = @"../../data/listTransactions.bin";
        static String binFileCustomer = @"../../data/Bikes.bin";

        private void ValidateDigit(KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar))
            {

                MessageBox.Show("Must be a digit only");
                e.Handled = true;

            }
        }


        //Funtion for controling enable/disable fields 
        private void activateControls(bool enBtnCreateAccount, bool enTxtTransDesc, bool enBtnDisplaAllAccounts, bool enBtnModifyProfil, bool enBtnDisplaAllTransactions,
                                        bool enBtnTransaction, bool enBtnReset, bool enBtnSave, bool enBtnSaveDatabase, bool enBtnConfirmTrans,
                                        bool enBtnCreateThisAcc, bool enTxtId, bool entxtFn, bool enTxtLn, bool enTxtPin,
                                        bool enTxtEmail, bool enTxtPhone, bool enTxtStreetNum, bool enTxtStreetName, bool enApto,
                                        bool enTxtCity, bool enTxtState, bool enTxtCountry, bool enTxtPostal, bool entxtBDay,
                                        bool enTxtBmonth, bool enTxtBYear, bool enTxtAccNum, bool enTxtAccPin, bool enAccType,
                                        bool enTxtODay, bool enTxtOMonth, bool enTxtOYear, bool enTxtTransBalance, bool enTxtAccBalance,
                                        bool enTransType, bool enSavingType, bool enCreditType, bool enCreditCategory, bool enChekingType,
                                        bool enTxtTransNo, bool enTransFrom, bool enTxtTransAmount, bool enTransTo, bool enTxtTransMonth,
                                        bool enTxtTransDay, bool enTxtTransYear)
        {

            //Enable Buttons
            buttonCreateAcc.Enabled = enBtnCreateAccount;
            buttonTransaction.Enabled = enBtnTransaction;
            buttonReset.Enabled = enBtnReset;
            buttonSaveFile.Enabled = enBtnSaveDatabase;
            buttonModify.Enabled = enBtnModifyProfil;
            buttonConfSave.Enabled = enBtnConfirmTrans;
            buttonDisplayTrans.Enabled = enBtnDisplaAllTransactions;
            buttonAddThisAcc.Enabled = enBtnCreateThisAcc;
            buttonDisplayAcc.Enabled = enBtnDisplaAllAccounts;

            //Enable TextBox Customer
            //Id most be disable the whole time
            enTxtId = false;
            textBoxId.Enabled = enTxtId;
            textBoxFn.Enabled = entxtFn;
            textBoxLn.Enabled = enTxtLn;
            textBoxPinCus.Enabled = enTxtPin;
            textBoxEmail.Enabled = enTxtEmail;
            textBoxPhone.Enabled = enTxtPhone;
            textBoxStrNum.Enabled = enTxtStreetNum;
            textBoxStrName.Enabled = enTxtStreetName;
            textBoxApp.Enabled = enApto;
            textBoxCity.Enabled = enTxtCity;
            textBoxProvince.Enabled = enTxtState;
            textBoxCountry.Enabled = enTxtCountry;
            textBoxZipCode.Enabled = enTxtPostal;
            textBoxBMonth.Enabled = enTxtBmonth;
            textBoxBDay.Enabled = entxtBDay;
            textBoxBYear.Enabled = enTxtBYear;

            //Enable TextBox Transactions
            textBoxTransNo.Enabled = enTxtTransNo;
            comboBoxTransType.Enabled = enTransType;
            comboBoxFromAcc.Enabled = enTransFrom;
            textBoxTransAmount.Enabled = enTxtTransAmount;
            comboBoxToAcc.Enabled = enTransTo;
            textBoxTransMonth.Enabled = enTxtTransMonth;
            textBoxTransDay.Enabled = enTxtTransDay;
            textBoxTransYear.Enabled = enTxtTransYear;
            textBoxTransDesc.Enabled = enTxtTransDesc;
            textBoxTransBalance.Enabled = enTxtTransBalance;

            //Enable TextBox Account
            textBoxAccNo.Enabled = enTxtAccNum;
            textBoxAccPin.Enabled = enTxtAccPin;
            comboBoxAccType.Enabled = enAccType;
            textBoxAccMonth.Enabled = enTxtOMonth;
            textBoxAccDay.Enabled = enTxtODay;
            textBoxAccYear.Enabled = enTxtOYear;
            comboBoxCheckingType.Enabled = enChekingType;
            comboBoxSavingType.Enabled = enSavingType;
            comboBoxCredType.Enabled = enCreditType;
            comboBoxCreditCategory.Enabled = enCreditCategory;
            textBoxAccBalance.Enabled = enTxtAccBalance;



        }

        public CustomerForm()
        {
            InitializeComponent();
        }

        private void CustomerForm_Load(object sender, EventArgs e)
        {


            foreach (EnumAccType element in Enum.GetValues(typeof(EnumAccType)))
            {
                comboBoxAccType.Items.Add(element);
                comboBoxAccType.Text = Convert.ToString(comboBoxAccType.Items[0]);
            }


            foreach (EnumCheckingType element in Enum.GetValues(typeof(EnumCheckingType)))
            {
                comboBoxCheckingType.Items.Add(element);
                comboBoxCheckingType.Text = Convert.ToString(comboBoxCheckingType.Items[0]);
            }


            foreach (EnumCreditCategory element in Enum.GetValues(typeof(EnumCreditCategory)))
            {
                comboBoxCreditCategory.Items.Add(element);
                comboBoxCreditCategory.Text = Convert.ToString(comboBoxCreditCategory.Items[0]);
            }


            foreach (EnumCreditType element in Enum.GetValues(typeof(EnumCreditType)))
            {
                comboBoxCredType.Items.Add(element);
                comboBoxCredType.Text = Convert.ToString(comboBoxCredType.Items[0]);
            }

            foreach (EnumSavingsType element in Enum.GetValues(typeof(EnumSavingsType)))
            {
                comboBoxSavingType.Items.Add(element);
                comboBoxSavingType.Text = Convert.ToString(comboBoxSavingType.Items[0]);
            }

            foreach (EnumTransType element in Enum.GetValues(typeof(EnumTransType)))
            {
                comboBoxTransType.Items.Add(element);
                comboBoxTransType.Text = Convert.ToString(comboBoxTransType.Items[0]);
            }

            activateControls(true, false, true, true, true,
                             true, true, true, true, false,
                             false, false, false, false, false,
                             false, false, false, false, false,
                             false, false, false, false, false,
                             false, false, false, false, false,
                             false, false, false, false, false,
                             false, false, false, false, false,
                             false, false, false, false, false,
                             false, false);
            //Pre-Fill the Customer filds with his/her information when the application starts
            if (File.Exists(binFileCustomer))
            {
                FileStream fs = new FileStream(binFileCustomer, FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                myCollectionsFromFile.CustomersList = (List<Customer>)bin.Deserialize(fs);

                fs.Close();
            }
            else
            {
                MessageBox.Show("The collection is empty");
            }

            foreach (Customer element in myCollectionsFromFile.CustomersList)
            {

                textBoxId.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Id);
                textBoxFn.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Fn);
                textBoxLn.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Ln);
                textBoxPinCus.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Ln);
                textBoxEmail.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Email);
                textBoxPhone.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Phone);
                textBoxStrNum.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Address.StrNum);
                textBoxStrName.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Address.StrName);
                textBoxApp.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Address.AptNum);
                textBoxCity.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Address.City);
                textBoxProvince.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Address.Province);
                textBoxCountry.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Address.Country);
                textBoxZipCode.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Address.ZipCode);
                textBoxStrNum.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Address.StrNum);
                textBoxBMonth.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].BirthDate.Month);
                textBoxBDay.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].BirthDate.Day);
                textBoxBYear.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].BirthDate.Year);

            }

        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            foreach (Control myControl in Controls)
            {
                if (myControl is TextBox)
                {
                    myControl.Text = "";
                }
                if (myControl is ComboBox)
                {
                    myControl.Text = Convert.ToString(comboBoxAccType.Items[0]);
                    myControl.Text = Convert.ToString(comboBoxCheckingType.Items[0]);
                    myControl.Text = Convert.ToString(comboBoxCreditCategory.Items[0]);
                    myControl.Text = Convert.ToString(comboBoxCredType.Items[0]);
                    myControl.Text = Convert.ToString(comboBoxSavingType.Items[0]);
                    myControl.Text = Convert.ToString(comboBoxTransType.Items[0]);

                }

                this.textBoxFn.Enabled = true;
                this.listViewTransactions.Items.Clear();
                this.listViewAccounts.Items.Clear();

                activateControls(true, false, true, true, true,
                             true, true, true, true, false,
                             false, false, false, false, false,
                             false, false, false, false, false,
                             false, false, false, false, false,
                             false, false, false, false, false,
                             false, false, false, false, false,
                             false, false, false, false, false,
                             false, false, false, false, false,
                             false, false);

                


            }
            foreach (Customer element in myCollectionsFromFile.CustomersList)
            {

                textBoxId.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Id);
                textBoxFn.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Fn);
                textBoxLn.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Ln);
                textBoxPinCus.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Ln);
                textBoxEmail.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Email);
                textBoxPhone.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Phone);
                textBoxStrNum.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Address.StrNum);
                textBoxStrName.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Address.StrName);
                textBoxApp.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Address.AptNum);
                textBoxCity.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Address.City);
                textBoxProvince.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Address.Province);
                textBoxCountry.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Address.Country);
                textBoxZipCode.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Address.ZipCode);
                textBoxStrNum.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].Address.StrNum);
                textBoxBMonth.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].BirthDate.Month);
                textBoxBDay.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].BirthDate.Day);
                textBoxBYear.Text = Convert.ToString(this.myCollectionsFromFile.CustomersList[index].BirthDate.Year);

            }
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonAddThisAcc_Click(object sender, EventArgs e)
        {
            this.textBoxAccNo.Focus();
            if (File.Exists(binFileCustomer))
            {
                FileStream fs = new FileStream(binFileCustomer, FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                myCollectionsFromFile.CustomersList = (List<Customer>)bin.Deserialize(fs);

                fs.Close();
            }

            Customer aCust = new Customer();
            aCust = theBank.CreateCustomer();

            foreach (Customer item in myCollectionsFromFile.CustomersList)
            {
                if (item.Id == Convert.ToInt32(textBoxId.Text))
                {
                    aCust = item;
                    Date anOpenDate = new Date();
                    anOpenDate.Month = Convert.ToInt32(textBoxAccMonth.Text);
                    anOpenDate.Day = Convert.ToInt32(textBoxAccDay.Text);
                    anOpenDate.Year = Convert.ToInt32(textBoxAccYear.Text);

                    if (comboBoxAccType.SelectedIndex == 1)
                    {
                        Checking aCheckingAcc = new Checking();

                        aCheckingAcc.AccNumber = Convert.ToInt64(textBoxAccNo.Text);
                        aCheckingAcc.AccPin = Convert.ToInt32(textBoxAccPin.Text);
                        aCheckingAcc.AccountType = (EnumAccType)comboBoxAccType.SelectedIndex;
                        aCheckingAcc.OpenDate = anOpenDate;
                        aCheckingAcc.AvailableBalance = 00.00;
                        aCheckingAcc.TransType = EnumTransType.undefined;
                        aCheckingAcc.TransCounter = 0;
                        aCheckingAcc.CType = (EnumCheckingType)comboBoxCheckingType.SelectedIndex;

                        this.myCollections.AccountsList.Add(aCheckingAcc);
                        aCust.MyAccounts.Add(aCheckingAcc);

                    }
                    //else if (tmpAccType == EnumAccType.savings)
                    else if (comboBoxAccType.SelectedIndex == 2)
                    {
                        Savings aSavingsAcc = new Savings();
      
          
                        aSavingsAcc.AccNumber = Convert.ToInt64(textBoxAccNo.Text);
                        aSavingsAcc.AccPin = Convert.ToInt32(textBoxAccPin.Text);
                        aSavingsAcc.AccountType = (EnumAccType)comboBoxAccType.SelectedIndex;
                        aSavingsAcc.OpenDate = anOpenDate;
                        aSavingsAcc.AvailableBalance = 00.00;
                        aSavingsAcc.TransType = EnumTransType.undefined;
                        aSavingsAcc.SType = (EnumSavingsType)comboBoxSavingType.SelectedIndex;

                        this.myCollections.AccountsList.Add(aSavingsAcc);
                        aCust.MyAccounts.Add(aSavingsAcc);


                    }
                    //else if (tmpAccType == EnumAccType.currency)
                    else if (comboBoxAccType.SelectedIndex == 3)
                    {
                        Savings aCurrentAcc = new Savings();

                        aCurrentAcc.AccNumber = Convert.ToInt64(textBoxAccNo.Text);
                        aCurrentAcc.AccPin = Convert.ToInt32(textBoxAccPin.Text);
                        aCurrentAcc.AccountType = (EnumAccType)comboBoxAccType.SelectedIndex;
                        aCurrentAcc.OpenDate = anOpenDate;
                        aCurrentAcc.AvailableBalance = 00.00;
                        aCurrentAcc.TransType = EnumTransType.undefined;
                        aCurrentAcc.SType = (EnumSavingsType)comboBoxSavingType.SelectedIndex;

                        this.myCollections.AccountsList.Add(aCurrentAcc);
                        aCust.MyAccounts.Add(aCurrentAcc);

                    }
                    //else if (tmpAccType == EnumAccType.credit)
                    else if (comboBoxAccType.SelectedIndex == 4)
                    {
                        Credit aCreditAcc = new Credit();

                        aCreditAcc.AccNumber = Convert.ToInt64(textBoxAccNo.Text);
                        aCreditAcc.AccPin = Convert.ToInt32(textBoxAccPin.Text);
                        aCreditAcc.AccountType = (EnumAccType)comboBoxAccType.SelectedIndex;
                        aCreditAcc.OpenDate = anOpenDate;
                        aCreditAcc.AvailableBalance = 00.00;
                        aCreditAcc.TransType = EnumTransType.undefined;
                        aCreditAcc.CreditType = (EnumCreditType)comboBoxCredType.SelectedIndex;
                        aCreditAcc.CreditCategory = (EnumCreditCategory)comboBoxCreditCategory.SelectedIndex;

                        this.myCollections.AccountsList.Add(aCreditAcc);
                        aCust.MyAccounts.Add(aCreditAcc);
                    }

                }

            }

            

            

            


            
        }

        private void textBoxApp_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxTransYear_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonCreateAcc_Click(object sender, EventArgs e)
        {
            this.textBoxAccNo.Focus();
            activateControls(true, false, true, false, true,
                                true, true, true, true, false,
                                true, false, false, false, false,
                                false, false, false, false, false,
                                false, false, false, false, false,
                                false, false, true, true, true,
                                true, true, true, false, false,
                                false, true, true, true, true,
                                false, false, false, false, false,
                                false, false);

        }

        private void textBoxAccNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateDigit(e);
        }

        private void textBoxAccMonth_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateDigit(e);
        }

        private void textBoxAccDay_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateDigit(e);
        }

        private void textBoxAccYear_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateDigit(e);
        }

        private void buttonTransaction_Click(object sender, EventArgs e)
        {
            this.textBoxTransNo.Focus();
            activateControls(true, true, true, false, true,
                                true, true, true, true, true,
                                false, false, false, false, false,
                                false, false, false, false, false,
                                false, false, false, false, false,
                                false, false, false, false, false,
                                false, false, false, true, false,
                                true, false, false, false, false,
                                true, true, true, true, true,
                                true, true);

            if (File.Exists(binFilepathAcc))
            {
                FileStream fs = new FileStream(binFilepathAcc, FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
               myCollectionsFromFile.AccountsList = (List<Account>)bin.Deserialize(fs);
                //FileStream fs2 = new FileStream(binFilepathTrans, FileMode.Open, FileAccess.Read);
                //transList = (DataAccess)bin.Deserialize(fs2);

                fs.Close();
                //fs2.Close();
            }

            foreach (Account item in myCollections.AccountsList)
            {
                comboBoxFromAcc.Text = Convert.ToString(this.myCollections.AccountsList[index].AccNumber);
                comboBoxToAcc.Text = Convert.ToString(this.myCollections.AccountsList[index].AccNumber);
            }

        }

        private void buttonConfSave_Click(object sender, EventArgs e)
        {
            if (File.Exists(binFilepathAcc))
            {
                FileStream fs = new FileStream(binFilepathAcc, FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                myCollectionsFromFile.AccountsList = (List<Account>)bin.Deserialize(fs);
                //FileStream fs2 = new FileStream(binFilepathTrans, FileMode.Open, FileAccess.Read);
                //transList = (DataAccess)bin.Deserialize(fs2);

                fs.Close();
                //fs2.Close();
            }

            foreach (Account item in myCollectionsFromFile.AccountsList)
            {
                
            }

            this.textBoxTransNo.Focus();

            String input, tmpDescription;
            long tmpTransNumb, tmpTrasAcc;
            Date tmpTransDate;
            double tmpAmount;
            EnumTransType tmpTransType;


            Transaction aTransaction = new Transaction();
            Checking aCheckingAcc = new Checking();
            Savings aSavingsAcc = new Savings();
            Savings aCurrentAcc = new Savings();
            Credit aCreditAcc = new Credit();

            Date aTransDate = new Date();
            aTransDate.Month = Convert.ToInt32(textBoxTransMonth.Text);
            aTransDate.Day = Convert.ToInt32(textBoxTransDay.Text);
            aTransDate.Year = Convert.ToInt32(textBoxTransYear.Text);

            input = textBoxTransNo.Text;
            tmpTransNumb = Convert.ToInt64(input);
            tmpDescription = textBoxTransDesc.Text;
            tmpTrasAcc = Convert.ToInt64(comboBoxFromAcc.Text);
            tmpAmount = Convert.ToDouble(textBoxTransAmount.Text);
            tmpTransDate = aTransDate;
            tmpTransType = (EnumTransType)comboBoxTransType.SelectedIndex;

            aTransaction.TransNumber = tmpTransNumb;
            aTransaction.Description = tmpDescription;
            aTransaction.AccountNumber = tmpTrasAcc;
            aTransaction.Amount = tmpAmount;
            aTransaction.TransDate = tmpTransDate;
            aTransaction.TransType = tmpTransType;

            this.myCollections.TransactionsList.Add(aTransaction);

            if (tmpTransType == EnumTransType.deposit)
            {
                if (aTransaction.AccountNumber == aCheckingAcc.AccNumber)
                {
                    aCheckingAcc.TransCounter = aCheckingAcc.TransCounter + 1;
                    aCheckingAcc.MakeTransaction();
                    this.myCollections.AccountsList.Add(aCheckingAcc);

                }
                else if (aTransaction.AccountNumber == aSavingsAcc.AccNumber)
                {
                    aSavingsAcc.MakeTransaction();
                    this.myCollections.AccountsList.Add(aSavingsAcc);
                }
                else if (aTransaction.AccountNumber == aCurrentAcc.AccNumber)
                {
                    aCurrentAcc.MakeTransaction();
                    this.myCollections.AccountsList.Add(aCurrentAcc);
                }
                else if (aTransaction.AccountNumber == aCreditAcc.AccNumber)
                {
                    aCreditAcc.MakeTransaction();
                    this.myCollections.AccountsList.Add(aCreditAcc);
                }

            }
            else if (tmpTransType == EnumTransType.payment)
            {
                if (aTransaction.AccountNumber == aCheckingAcc.AccNumber)
                {
                    aCheckingAcc.TransCounter = aCheckingAcc.TransCounter + 1;
                    aCheckingAcc.MakeTransaction();
                    this.myCollections.AccountsList.Add(aCheckingAcc);

                }
                else if (aTransaction.AccountNumber == aSavingsAcc.AccNumber)
                {
                    aSavingsAcc.MakeTransaction();
                    this.myCollections.AccountsList.Add(aSavingsAcc);
                }
                else if (aTransaction.AccountNumber == aCurrentAcc.AccNumber)
                {
                    aCurrentAcc.MakeTransaction();
                    this.myCollections.AccountsList.Add(aCurrentAcc);
                }
                else if (aTransaction.AccountNumber == aCreditAcc.AccNumber)
                {
                    aCreditAcc.MakeTransaction();
                    this.myCollections.AccountsList.Add(aCreditAcc);
                }


            }
            else if (tmpTransType == EnumTransType.transfer)
            {
                if (aTransaction.AccountNumber == aCheckingAcc.AccNumber)
                {
                    aCheckingAcc.TransCounter = aCheckingAcc.TransCounter + 1;
                    aCheckingAcc.MakeTransaction();
                    this.myCollections.AccountsList.Add(aCheckingAcc);

                }
                else if (aTransaction.AccountNumber == aSavingsAcc.AccNumber)
                {
                    aSavingsAcc.MakeTransaction();
                    this.myCollections.AccountsList.Add(aSavingsAcc);
                }
                else if (aTransaction.AccountNumber == aCurrentAcc.AccNumber)
                {
                    aCurrentAcc.MakeTransaction();
                    this.myCollections.AccountsList.Add(aCurrentAcc);
                }
                else if (aTransaction.AccountNumber == aCreditAcc.AccNumber)
                {
                    aCreditAcc.MakeTransaction();
                    this.myCollections.AccountsList.Add(aCreditAcc);
                }


            }
            else if (tmpTransType == EnumTransType.withdraw)
            {
                if (aTransaction.AccountNumber == aCheckingAcc.AccNumber)
                {
                    aCheckingAcc.TransCounter = aCheckingAcc.TransCounter + 1;
                    aCheckingAcc.MakeTransaction();
                    this.myCollections.AccountsList.Add(aCheckingAcc);

                }
                else if (aTransaction.AccountNumber == aSavingsAcc.AccNumber)
                {
                    aSavingsAcc.MakeTransaction();
                    this.myCollections.AccountsList.Add(aSavingsAcc);
                }
                else if (aTransaction.AccountNumber == aCurrentAcc.AccNumber)
                {
                    aCurrentAcc.MakeTransaction();
                    this.myCollections.AccountsList.Add(aCurrentAcc);
                }
                else if (aTransaction.AccountNumber == aCreditAcc.AccNumber)
                {
                    aCreditAcc.MakeTransaction();
                    this.myCollections.AccountsList.Add(aCreditAcc);
                }

            }
        }

        private void buttonSaveFile_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream(binFilepathAcc, FileMode.OpenOrCreate, FileAccess.Write);
            BinaryFormatter writer = new BinaryFormatter();
            writer.Serialize(fs, myCollections.AccountsList);//write accounts list to serialize file

            fs.Close();

        }

        private void comboBoxFromAcc_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (File.Exists(binFilepathAcc))
            //{
            //    FileStream fs = new FileStream(binFilepathAcc, FileMode.Open, FileAccess.Read);
            //    BinaryFormatter bin = new BinaryFormatter();
            //    accsList = (DataAccess)bin.Deserialize(fs);
            //    FileStream fs2 = new FileStream(binFilepathTrans, FileMode.Open, FileAccess.Read);
            //    transList = (DataAccess)bin.Deserialize(fs2);

            //    fs.Close();
            //    fs2.Close();
            //}

            //foreach (Account item in accsList.AccountsList)
            //{
            //    //ListViewItem element = new ListViewItem(Convert.ToString(item.AccNumber));
            //    ComboBox element = new ComboBox();
            //    element.Items.Add(Convert.ToString(item.AccNumber));

            //    this.comboBoxFromAcc.Items.Add(element.ToString());

            //}
        }

        private void comboBoxToAcc_SelectedIndexChanged(object sender, EventArgs e)
        {
            //    if (File.Exists(binFilepathAcc))
            //    {
            //        FileStream fs = new FileStream(binFilepathAcc, FileMode.Open, FileAccess.Read);
            //        BinaryFormatter bin = new BinaryFormatter();
            //        accsList = (DataAccess)bin.Deserialize(fs);

            //        fs.Close();
            //    }
            //    foreach (Account item in accsList.AccountsList)
            //    {
            //        //ListViewItem element = new ListViewItem(Convert.ToString(item.AccNumber));
            //        ComboBox element = new ComboBox();
            //        element.Items.Add(Convert.ToString(item.AccNumber));

            //        this.comboBoxToAcc.Items.Add(element.ToString());

            //    }
        }

        private void textBoxId_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void textBoxFn_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxFn_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void buttonModify_Click(object sender, EventArgs e)
        {
            this.textBoxFn.Focus();
            activateControls(true, true, true, true, true,
                                true, true, true, true, true,
                                false, false, true, true, true,
                                true, true, true, true, true,
                                true, true, true, true, true,
                                true, true, false, false, false,
                                false, false, false, false, false,
                                false, false, false, false, false,
                                false, false, false, false, false,
                                false, false);
        }

        private void buttonDisplayAcc_Click(object sender, EventArgs e)
        {
            //Display the information from FILE
            if (File.Exists(binFilepathAcc))
            {
                FileStream fs = new FileStream(binFilepathAcc, FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                myCollectionsFromFile.AccountsList = (List<Account>)bin.Deserialize(fs);
                //FileStream fs2 = new FileStream(binFilepathTrans, FileMode.Open, FileAccess.Read);
                //transList = (DataAccess)bin.Deserialize(fs2);

                fs.Close();
                //fs2.Close();
            }

            if (this.myCollectionsFromFile.AccountsList.Capacity != 0)
            {
                foreach (Account element in this.myCollectionsFromFile.AccountsList)
                {
                    ListViewItem item = new ListViewItem(Convert.ToString(element.AccNumber));

                    item.SubItems.Add(Convert.ToString(element.AccPin));
                    item.SubItems.Add(Convert.ToString(element.AccountType));
                    item.SubItems.Add(Convert.ToString(element.OpenDate.Month));
                    item.SubItems.Add(Convert.ToString(element.OpenDate.Day));
                    item.SubItems.Add(Convert.ToString(element.OpenDate.Year));
                    item.SubItems.Add(Convert.ToString(element.AvailableBalance));
                    item.SubItems.Add(Convert.ToString(element.TransType));

                    this.listViewAccounts.Items.Add(item);
                }

            }
            else
            {
                MessageBox.Show("...NO DATA.....");
            }
        }

        private void listViewAccounts_SelectedIndexChanged(object sender, EventArgs e)
        {
            index = listViewAccounts.FocusedItem.Index;

            textBoxAccNo.Text = Convert.ToString(this.myCollectionsFromFile.AccountsList[index].AccNumber);
            textBoxAccPin.Text = Convert.ToString(this.myCollectionsFromFile.AccountsList[index].AccPin);
            comboBoxAccType.Text = Convert.ToString(this.myCollectionsFromFile.AccountsList[index].AccountType);
            textBoxAccMonth.Text = Convert.ToString(this.myCollectionsFromFile.AccountsList[index].OpenDate.Month);
            textBoxAccDay.Text = Convert.ToString(this.myCollectionsFromFile.AccountsList[index].OpenDate.Day);
            textBoxAccYear.Text = Convert.ToString(this.myCollectionsFromFile.AccountsList[index].OpenDate.Year);
            textBoxAccBalance.Text = Convert.ToString(this.myCollectionsFromFile.AccountsList[index].AvailableBalance);
            comboBoxAccType.Text = Convert.ToString(this.myCollectionsFromFile.AccountsList[index].TransType);
        }

        private void buttonDisplayTrans_Click(object sender, EventArgs e)
        {
            if (File.Exists(binFilepathTrans))
            {
                //FileStream fs = new FileStream(binFilepathAcc, FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                //accsList = (DataAccess)bin.Deserialize(fs);
                FileStream fs2 = new FileStream(binFilepathTrans, FileMode.Open, FileAccess.Read);
                myCollectionsFromFile.TransactionsList = (List<Transaction>)bin.Deserialize(fs2);

                //fs.Close();
                fs2.Close();
            }

            if (this.myCollectionsFromFile.TransactionsList.Capacity != 0)
            {
                foreach (Transaction element in this.myCollectionsFromFile.TransactionsList)
                {
                    ListViewItem item = new ListViewItem(Convert.ToString(element.TransNumber));

                    item.SubItems.Add(Convert.ToString(element.Description));
                    item.SubItems.Add(Convert.ToString(element.TransDate));
                    item.SubItems.Add(Convert.ToString(element.Amount));
                    item.SubItems.Add(Convert.ToString(element.AccountNumber));
                    item.SubItems.Add(Convert.ToString(element.TransType));



                    this.listViewTransactions.Items.Add(item);
                }

            }
            else
            {
                MessageBox.Show("...NO DATA.....");
            }
        }

        private void listViewTransactions_SelectedIndexChanged(object sender, EventArgs e)
        {
            index = listViewTransactions.FocusedItem.Index;

            textBoxTransNo.Text = Convert.ToString(this.myCollectionsFromFile.TransactionsList[index].TransNumber);
            textBoxTransDesc.Text = Convert.ToString(this.myCollectionsFromFile.TransactionsList[index].Description);
            textBoxTransMonth.Text = Convert.ToString(this.myCollectionsFromFile.TransactionsList[index].TransDate.Month);
            textBoxTransDay.Text = Convert.ToString(this.myCollectionsFromFile.TransactionsList[index].TransDate.Day);
            textBoxTransYear.Text = Convert.ToString(this.myCollectionsFromFile.TransactionsList[index].TransDate.Year);
            textBoxTransAmount.Text = Convert.ToString(this.myCollectionsFromFile.TransactionsList[index].Amount);
            comboBoxFromAcc.Text = Convert.ToString(this.myCollectionsFromFile.TransactionsList[index].AccountNumber);
            comboBoxTransType.Text = Convert.ToString(this.myCollectionsFromFile.TransactionsList[index].TransType);
        }

        private void buttonSaveTransToFile_Click(object sender, EventArgs e)
        {
            FileStream fs2 = new FileStream(binFilepathTrans, FileMode.OpenOrCreate, FileAccess.Write);
            BinaryFormatter writer = new BinaryFormatter();
            writer.Serialize(fs2, myCollections.TransactionsList);//write transactions list to serialize file

            fs2.Close();
        }

        private void textBoxAccNo_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxAccPin_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxAccMonth_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
