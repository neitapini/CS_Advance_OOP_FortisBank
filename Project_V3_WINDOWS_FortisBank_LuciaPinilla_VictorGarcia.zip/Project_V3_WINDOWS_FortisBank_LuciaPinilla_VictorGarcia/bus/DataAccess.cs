﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.bus
{
    [Serializable]
    public class DataAccess
    {
        List<Customer> customersList = new List<Customer>();
        List<Account> accountsList = new List<Account>();
        List<Transaction> transactionsList = new List<Transaction>();

        public List<Customer> CustomersList { get => customersList; set => customersList = value; }
        public List<Account> AccountsList { get => accountsList; set => accountsList = value; }
        public List<Transaction> TransactionsList { get => transactionsList; set => transactionsList = value; }


        public DataAccess()
        {

        }
        public DataAccess(List<Customer> customersList, List<Account> accountsList, List<Transaction> transactionsList)
        {
            this.CustomersList = customersList;
            this.AccountsList = accountsList;
            this.TransactionsList = transactionsList;
        }

        override
        public String ToString()
        {
            return this.CustomersList + " - " +
                    this.AccountsList + " - " +
                    this.TransactionsList;

        }


    }
}
