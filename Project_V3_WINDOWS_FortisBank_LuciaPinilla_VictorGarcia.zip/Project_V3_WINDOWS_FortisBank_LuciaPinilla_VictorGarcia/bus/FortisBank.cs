﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.bus
{
    [Serializable]
    public class FortisBank
    {
        private EnumAccType type;

        //List<Customer> customersList = new List<Customer>();
        //List<Account> accountsList = new List<Account>();
        //List<Transaction> transactionsList = new List<Transaction>();

        //public List<Customer> CustomersList { get => customersList; set => customersList = value; }
        //public List<Account> AccountsList { get => accountsList; set => accountsList = value; }
        //public List<Transaction> TransactionsList { get => transactionsList; set => transactionsList = value; }
        public EnumAccType Type { get => type; set => type = value; }

        public FortisBank()
        {

        }
        //public FortisBank(List<Customer> customersList, List<Account> accountsList, List<Transaction> transactionsList)
        //{
        //    this.CustomersList = customersList;
        //    this.AccountsList = accountsList;
        //    this.TransactionsList = transactionsList;
        //}
        public FortisBank( EnumAccType type)
        {
            
            this.Type = type;
        }
    override
    public String ToString()
    {
        return "Account type: " +  this.Type;
    }


    public Savings OpenSavingsAccount(EnumAccType type)
        {
            if (type == EnumAccType.savings)
            {
                Savings aSavingsAccount = new Savings();
                return aSavingsAccount;
            }
            else if (type == EnumAccType.currency)
            {
                Savings aSavingsCurrencyAcc = new Savings();
                return aSavingsCurrencyAcc;
            }
            else
            {
                return null;
            }
        }
        public Credit OpenCreditAccount(EnumAccType type)
        {
            if (type == EnumAccType.credit)
            {
                Credit aCreditAccount = new Credit();
                return aCreditAccount;
            }
            else
            {
                return null;
            }
        }
        public Checking OpenCheckingAccount(EnumAccType type)
        {
            if (type == EnumAccType.credit)
            {
                Checking aChekingAccount = new Checking();
                return aChekingAccount;
            }
            else
            {
                return null;
            }

        }
        public Customer CreateCustomer()
        {
            
            Customer aNewCutomer = new Customer();

            return aNewCutomer;
        }


    }
}
