﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.bus
{
    [Serializable]
    public class Date
    {
        private int month;
        private int day;
        private int year;

        public int Month
        {
            get { return month; }
            set
            {
                if (value.Equals(""))
                {
                    FormatException fe = new FormatException();
                    throw (fe);
                }
                else if (value < 0)
                {
                    ValidateNegativeNumber e = new ValidateNegativeNumber("The input is a negative value, please enter a positive value");
                    throw (e);
                }
                else if (value > 12)
                {
                    ValidateDate m = new ValidateDate("The month has to be between 1 and 12");
                    throw (m);
                }

                month = value;
            }
        }
        public int Day
        {
            get { return day; }
            set
            {
                if (value.Equals(""))
                {
                    FormatException fe = new FormatException();
                    throw (fe);
                }
                else if (value < 0)
                {
                    ValidateNegativeNumber e = new ValidateNegativeNumber("The input is a negative value, please enter a positive value");
                    throw (e);
                }
                else if (value > 31)
                {
                    ValidateDate m = new ValidateDate("The day has to be between 1 and 31");
                    throw (m);
                }

                day = value;
            }
        }
        public int Year
        {
            get { return year; }
            set
            {
                if (value.Equals(""))
                {
                    FormatException fe = new FormatException();
                    throw (fe);
                }
                else if (value < 0)
                {
                    ValidateNegativeNumber e = new ValidateNegativeNumber("The input is a negative value, please enter a positive value");
                    throw (e);
                }
                else if (value > DateTime.Now.Year)
                {
                    ValidateDate m = new ValidateDate("The year is in the future");
                    throw (m);
                }

                year = value;
            }
        }

        public Date()
        {
            this.Day = 00;
            this.Month = 00;
            this.Year = 0000;
        }
        public Date(int day, int month, int year)
        {

            this.Day = day;
            this.Month = month;
            this.Year = year;
        }
        override
        public String ToString()
        {
            return this.Month + "/" + this.Day + "/" + this.Year;
        }
    }
}
