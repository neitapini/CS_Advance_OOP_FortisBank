﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.bus
{
    [Serializable]
    public class Checking : Account
    {

        private const int freeTrans = 4;
        private const double intRate = Rates.checkingAccoutRate;
        private int transCounter;
        private double extraFees;
        private const double feePerAdditionalTrans = 0.05;
        private double monthlyFees;
        private EnumCheckingType cType;

        public static int FreeTrans => freeTrans;
        public int TransCounter { get => transCounter; set => transCounter = value; }
        public double ExtraFees { get => extraFees; set => extraFees = value; }
        public static double FeePerAdditionalTrans => feePerAdditionalTrans;
        public EnumCheckingType CType { get => cType; set => cType = value; }

        public double MonthlyFees
        {
            get => monthlyFees;
            set
            {
                //Set a monthlyFees of 15 dolars for a regular checking account
                if (CType == EnumCheckingType.regular)
                { monthlyFees = 15; }
                //Set a monthlyFees of 10 dolars for a student checking account
                else if (CType == EnumCheckingType.student)
                { monthlyFees = 10; }
                //Set a monthlyFees of 0 dolars for a VIP checking account
                else if (CType == EnumCheckingType.VIP)
                { monthlyFees = 0; }
                //Set a monthlyFees of 25 dolars for a business checking account
                else if (CType == EnumCheckingType.business)
                { monthlyFees = 25; }

            }

        }



        public Checking()
        {
            this.TransCounter = 0;
            this.ExtraFees = 0.0;
            this.MonthlyFees = 0.0;
            this.CType = EnumCheckingType.undefined;
        }

        public Checking(int transCounter, double extraFees)
        {
            this.TransCounter = transCounter;
            this.ExtraFees = extraFees;
        }
        public Checking(int transCounter, double extraFees, double monthlyFees)
        {
            this.TransCounter = transCounter;
            this.ExtraFees = extraFees;
            this.MonthlyFees = monthlyFees;
        }
        public Checking(int transCounter, double extraFees, double monthlyFees, EnumCheckingType cType)
        {
            this.TransCounter = transCounter;
            this.ExtraFees = extraFees;
            this.MonthlyFees = monthlyFees;
            this.CType = cType;
        }
        override
        public String ToString()
        {
            return base.ToString() + " - " + this.TransCounter + " - " + this.ExtraFees + " - " + this.MonthlyFees + " - " + this.CType;
        }

        override
        public double MakeTransaction()
        {
            Transaction aTrans = new Transaction();
            if (base.TransType == EnumTransType.deposit)
            {
                return base.AvailableBalance + aTrans.Amount;
            }
            //Limited number of free withdraw ans purchase transactions
            else if (base.TransType == EnumTransType.withdraw || base.TransType == EnumTransType.payment)
            {
                if (TransCounter > FreeTrans)
                {
                    //warn the customer about exceeding the const freeTrans
                    Console.WriteLine("You are exceeding the number of free transactions");
                    ExtraFees = FeePerAdditionalTrans * (Convert.ToDouble(TransCounter - FreeTrans));

                    return base.AvailableBalance - aTrans.Amount - ExtraFees;
                }
                else { return base.AvailableBalance - aTrans.Amount; }
            }
            else if (base.TransType == EnumTransType.transfer)
            {
                return base.AvailableBalance - aTrans.Amount;
            }
            else
            { return base.AvailableBalance; }

        }

    }
}
