﻿namespace Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.prod
{
    partial class FortisBankForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FortisBankForm));
            System.Windows.Forms.ListViewGroup listViewGroup7 = new System.Windows.Forms.ListViewGroup("ListViewGroup", System.Windows.Forms.HorizontalAlignment.Left);
            this.btnReadFile = new System.Windows.Forms.Button();
            this.btnWriteFile = new System.Windows.Forms.Button();
            this.cboCredCateg = new System.Windows.Forms.ComboBox();
            this.cboCredType = new System.Windows.Forms.ComboBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.cboSavingType = new System.Windows.Forms.ComboBox();
            this.label33 = new System.Windows.Forms.Label();
            this.btnDisplayAllAcc = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.lstCustomer = new System.Windows.Forms.ListView();
            this.lstCustId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstCusFn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.LstCusLn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstCustPin = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstCustEmail = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstCustPhone = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstCusStNum = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstCustStName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstCustApto = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstCustCity = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstCustState = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstCustCountry = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstCustPostal = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstCustBDay = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstCustBMonth = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstCustBYear = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label32 = new System.Windows.Forms.Label();
            this.cboCheckingType = new System.Windows.Forms.ComboBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.txtSearchBox = new System.Windows.Forms.TextBox();
            this.btnSaveCustomer = new System.Windows.Forms.Button();
            this.btnSaveAccount = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.listViewAccount = new System.Windows.Forms.ListView();
            this.lstAccNumber = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstAcPin = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstAcType = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstAccDay = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstAcMonth = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstAcYear = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstAcBalance = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstAccTrans = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cboTransaction = new System.Windows.Forms.ComboBox();
            this.txtBalance = new System.Windows.Forms.TextBox();
            this.txtAccYear = new System.Windows.Forms.TextBox();
            this.txtAcMonth = new System.Windows.Forms.TextBox();
            this.txtADay = new System.Windows.Forms.TextBox();
            this.cboAccountType = new System.Windows.Forms.ComboBox();
            this.txtAccountPin = new System.Windows.Forms.TextBox();
            this.txtAccountNum = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.btnCreateAccount = new System.Windows.Forms.Button();
            this.btnDisplayCustomers = new System.Windows.Forms.Button();
            this.btnModify = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnCreateCustomer = new System.Windows.Forms.Button();
            this.txtBYear = new System.Windows.Forms.TextBox();
            this.txtBMonth = new System.Windows.Forms.TextBox();
            this.txtBDay = new System.Windows.Forms.TextBox();
            this.txtStreetName = new System.Windows.Forms.TextBox();
            this.txtPostalCode = new System.Windows.Forms.TextBox();
            this.txtCountry = new System.Windows.Forms.TextBox();
            this.txtState = new System.Windows.Forms.TextBox();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtAptoNum = new System.Windows.Forms.TextBox();
            this.txtStreetNum = new System.Windows.Forms.TextBox();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtPinCustomer = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtId = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnReadFile
            // 
            this.btnReadFile.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnReadFile.BackgroundImage")));
            this.btnReadFile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnReadFile.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnReadFile.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReadFile.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnReadFile.Location = new System.Drawing.Point(546, 24);
            this.btnReadFile.Name = "btnReadFile";
            this.btnReadFile.Size = new System.Drawing.Size(98, 34);
            this.btnReadFile.TabIndex = 156;
            this.btnReadFile.Text = "Read File";
            this.btnReadFile.UseVisualStyleBackColor = true;
            this.btnReadFile.Click += new System.EventHandler(this.btnReadFile_Click);
            // 
            // btnWriteFile
            // 
            this.btnWriteFile.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnWriteFile.BackgroundImage")));
            this.btnWriteFile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnWriteFile.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnWriteFile.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWriteFile.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnWriteFile.Location = new System.Drawing.Point(752, 24);
            this.btnWriteFile.Name = "btnWriteFile";
            this.btnWriteFile.Size = new System.Drawing.Size(96, 34);
            this.btnWriteFile.TabIndex = 155;
            this.btnWriteFile.Text = "Save To File";
            this.btnWriteFile.UseVisualStyleBackColor = true;
            this.btnWriteFile.Click += new System.EventHandler(this.btnWriteFile_Click);
            // 
            // cboCredCateg
            // 
            this.cboCredCateg.FormattingEnabled = true;
            this.cboCredCateg.Location = new System.Drawing.Point(728, 399);
            this.cboCredCateg.Name = "cboCredCateg";
            this.cboCredCateg.Size = new System.Drawing.Size(121, 21);
            this.cboCredCateg.TabIndex = 154;
            // 
            // cboCredType
            // 
            this.cboCredType.FormattingEnabled = true;
            this.cboCredType.Location = new System.Drawing.Point(727, 361);
            this.cboCredType.Name = "cboCredType";
            this.cboCredType.Size = new System.Drawing.Size(121, 21);
            this.cboCredType.TabIndex = 153;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label35.Location = new System.Drawing.Point(614, 407);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(98, 13);
            this.label35.TabIndex = 152;
            this.label35.Text = "CREDIT CATEGORY";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label34.Location = new System.Drawing.Point(617, 369);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(70, 13);
            this.label34.TabIndex = 151;
            this.label34.Text = "CREDIT TYPE";
            // 
            // cboSavingType
            // 
            this.cboSavingType.FormattingEnabled = true;
            this.cboSavingType.Location = new System.Drawing.Point(727, 324);
            this.cboSavingType.Name = "cboSavingType";
            this.cboSavingType.Size = new System.Drawing.Size(121, 21);
            this.cboSavingType.TabIndex = 150;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label33.Location = new System.Drawing.Point(614, 338);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(94, 13);
            this.label33.TabIndex = 149;
            this.label33.Text = "SAVING ACC TYPE";
            // 
            // btnDisplayAllAcc
            // 
            this.btnDisplayAllAcc.BackgroundImage = global::Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.Properties.Resources.button_3;
            this.btnDisplayAllAcc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDisplayAllAcc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDisplayAllAcc.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisplayAllAcc.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDisplayAllAcc.Location = new System.Drawing.Point(740, 466);
            this.btnDisplayAllAcc.Name = "btnDisplayAllAcc";
            this.btnDisplayAllAcc.Size = new System.Drawing.Size(96, 34);
            this.btnDisplayAllAcc.TabIndex = 148;
            this.btnDisplayAllAcc.Text = "Exit";
            this.btnDisplayAllAcc.UseVisualStyleBackColor = true;
            this.btnDisplayAllAcc.Click += new System.EventHandler(this.btnDisplayAllAcc_Click);
            // 
            // btnReset
            // 
            this.btnReset.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnReset.BackgroundImage")));
            this.btnReset.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnReset.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnReset.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnReset.Location = new System.Drawing.Point(650, 24);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(96, 34);
            this.btnReset.TabIndex = 147;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // lstCustomer
            // 
            this.lstCustomer.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lstCustId,
            this.lstCusFn,
            this.LstCusLn,
            this.lstCustPin,
            this.lstCustEmail,
            this.lstCustPhone,
            this.lstCusStNum,
            this.lstCustStName,
            this.lstCustApto,
            this.lstCustCity,
            this.lstCustState,
            this.lstCustCountry,
            this.lstCustPostal,
            this.lstCustBDay,
            this.lstCustBMonth,
            this.lstCustBYear});
            this.lstCustomer.Location = new System.Drawing.Point(319, 97);
            this.lstCustomer.Name = "lstCustomer";
            this.lstCustomer.Size = new System.Drawing.Size(234, 114);
            this.lstCustomer.TabIndex = 146;
            this.lstCustomer.UseCompatibleStateImageBehavior = false;
            this.lstCustomer.View = System.Windows.Forms.View.Details;
            this.lstCustomer.SelectedIndexChanged += new System.EventHandler(this.lstCustomer_SelectedIndexChanged);
            // 
            // lstCustId
            // 
            this.lstCustId.Text = "Id";
            // 
            // lstCusFn
            // 
            this.lstCusFn.Text = "Name";
            // 
            // LstCusLn
            // 
            this.LstCusLn.Text = "L.Name";
            // 
            // lstCustPin
            // 
            this.lstCustPin.Text = "PIN";
            // 
            // lstCustEmail
            // 
            this.lstCustEmail.Text = "email";
            // 
            // lstCustPhone
            // 
            this.lstCustPhone.Text = "PhoneNumber";
            // 
            // lstCusStNum
            // 
            this.lstCusStNum.Text = "StreetNum";
            // 
            // lstCustStName
            // 
            this.lstCustStName.Text = "StreetName";
            // 
            // lstCustApto
            // 
            this.lstCustApto.Text = "Apto";
            // 
            // lstCustCity
            // 
            this.lstCustCity.Text = "City";
            // 
            // lstCustState
            // 
            this.lstCustState.Text = "Province";
            // 
            // lstCustCountry
            // 
            this.lstCustCountry.Text = "Country";
            // 
            // lstCustPostal
            // 
            this.lstCustPostal.Text = "PostCode";
            // 
            // lstCustBDay
            // 
            this.lstCustBDay.Text = "BDay";
            // 
            // lstCustBMonth
            // 
            this.lstCustBMonth.Text = "BMonth";
            // 
            // lstCustBYear
            // 
            this.lstCustBYear.Text = "BYear";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.LightSeaGreen;
            this.label32.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(388, 73);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(101, 13);
            this.label32.TabIndex = 145;
            this.label32.Text = "LIST OF CUSTOMER";
            // 
            // cboCheckingType
            // 
            this.cboCheckingType.FormattingEnabled = true;
            this.cboCheckingType.Location = new System.Drawing.Point(727, 283);
            this.cboCheckingType.Name = "cboCheckingType";
            this.cboCheckingType.Size = new System.Drawing.Size(121, 21);
            this.cboCheckingType.TabIndex = 144;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label31.Location = new System.Drawing.Point(617, 286);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(92, 13);
            this.label31.TabIndex = 143;
            this.label31.Text = "CHECK.ACC TYPE";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.LightSeaGreen;
            this.label30.Font = new System.Drawing.Font("Bahnschrift", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label30.Location = new System.Drawing.Point(318, 387);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(98, 13);
            this.label30.TabIndex = 142;
            this.label30.Text = "Enter Customer ID\r\n";
            // 
            // txtSearchBox
            // 
            this.txtSearchBox.Location = new System.Drawing.Point(319, 404);
            this.txtSearchBox.Name = "txtSearchBox";
            this.txtSearchBox.Size = new System.Drawing.Size(126, 20);
            this.txtSearchBox.TabIndex = 141;
            // 
            // btnSaveCustomer
            // 
            this.btnSaveCustomer.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSaveCustomer.BackgroundImage")));
            this.btnSaveCustomer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSaveCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSaveCustomer.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveCustomer.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSaveCustomer.Location = new System.Drawing.Point(40, 466);
            this.btnSaveCustomer.Name = "btnSaveCustomer";
            this.btnSaveCustomer.Size = new System.Drawing.Size(96, 34);
            this.btnSaveCustomer.TabIndex = 140;
            this.btnSaveCustomer.Text = "Save Customer";
            this.btnSaveCustomer.UseVisualStyleBackColor = true;
            this.btnSaveCustomer.Click += new System.EventHandler(this.btnSaveCustomer_Click);
            // 
            // btnSaveAccount
            // 
            this.btnSaveAccount.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSaveAccount.BackgroundImage")));
            this.btnSaveAccount.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSaveAccount.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSaveAccount.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveAccount.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSaveAccount.Location = new System.Drawing.Point(147, 466);
            this.btnSaveAccount.Name = "btnSaveAccount";
            this.btnSaveAccount.Size = new System.Drawing.Size(96, 34);
            this.btnSaveAccount.TabIndex = 139;
            this.btnSaveAccount.Text = "Save Account";
            this.btnSaveAccount.UseVisualStyleBackColor = true;
            this.btnSaveAccount.Click += new System.EventHandler(this.btnSaveAccount_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.LightSeaGreen;
            this.label28.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(388, 222);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(107, 13);
            this.label28.TabIndex = 136;
            this.label28.Text = "LIST OF ACCCOUNTS";
            this.label28.Click += new System.EventHandler(this.label28_Click);
            // 
            // listViewAccount
            // 
            this.listViewAccount.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lstAccNumber,
            this.lstAcPin,
            this.lstAcType,
            this.lstAccDay,
            this.lstAcMonth,
            this.lstAcYear,
            this.lstAcBalance,
            this.lstAccTrans});
            listViewGroup7.Header = "ListViewGroup";
            listViewGroup7.Name = "listViewGroup2";
            this.listViewAccount.Groups.AddRange(new System.Windows.Forms.ListViewGroup[] {
            listViewGroup7});
            this.listViewAccount.Location = new System.Drawing.Point(319, 238);
            this.listViewAccount.Name = "listViewAccount";
            this.listViewAccount.Size = new System.Drawing.Size(234, 121);
            this.listViewAccount.TabIndex = 135;
            this.listViewAccount.UseCompatibleStateImageBehavior = false;
            this.listViewAccount.View = System.Windows.Forms.View.Details;
            this.listViewAccount.SelectedIndexChanged += new System.EventHandler(this.listViewAccount_SelectedIndexChanged);
            // 
            // lstAccNumber
            // 
            this.lstAccNumber.Text = "Number";
            // 
            // lstAcPin
            // 
            this.lstAcPin.Text = "PIN";
            this.lstAcPin.Width = 54;
            // 
            // lstAcType
            // 
            this.lstAcType.Text = "Type";
            // 
            // lstAccDay
            // 
            this.lstAccDay.Text = "Open Day";
            // 
            // lstAcMonth
            // 
            this.lstAcMonth.Text = "";
            // 
            // lstAcYear
            // 
            this.lstAcYear.Text = "Year";
            // 
            // lstAcBalance
            // 
            this.lstAcBalance.Text = "Balance";
            // 
            // lstAccTrans
            // 
            this.lstAccTrans.Text = "Transaction";
            // 
            // cboTransaction
            // 
            this.cboTransaction.FormattingEnabled = true;
            this.cboTransaction.Location = new System.Drawing.Point(727, 241);
            this.cboTransaction.Name = "cboTransaction";
            this.cboTransaction.Size = new System.Drawing.Size(121, 21);
            this.cboTransaction.TabIndex = 134;
            // 
            // txtBalance
            // 
            this.txtBalance.Location = new System.Drawing.Point(727, 215);
            this.txtBalance.Name = "txtBalance";
            this.txtBalance.Size = new System.Drawing.Size(121, 20);
            this.txtBalance.TabIndex = 133;
            // 
            // txtAccYear
            // 
            this.txtAccYear.Location = new System.Drawing.Point(806, 181);
            this.txtAccYear.Name = "txtAccYear";
            this.txtAccYear.Size = new System.Drawing.Size(42, 20);
            this.txtAccYear.TabIndex = 132;
            // 
            // txtAcMonth
            // 
            this.txtAcMonth.Location = new System.Drawing.Point(707, 180);
            this.txtAcMonth.Name = "txtAcMonth";
            this.txtAcMonth.Size = new System.Drawing.Size(34, 20);
            this.txtAcMonth.TabIndex = 131;
            // 
            // txtADay
            // 
            this.txtADay.Location = new System.Drawing.Point(754, 181);
            this.txtADay.Name = "txtADay";
            this.txtADay.Size = new System.Drawing.Size(35, 20);
            this.txtADay.TabIndex = 130;
            // 
            // cboAccountType
            // 
            this.cboAccountType.FormattingEnabled = true;
            this.cboAccountType.Location = new System.Drawing.Point(727, 142);
            this.cboAccountType.Name = "cboAccountType";
            this.cboAccountType.Size = new System.Drawing.Size(121, 21);
            this.cboAccountType.TabIndex = 129;
            // 
            // txtAccountPin
            // 
            this.txtAccountPin.Location = new System.Drawing.Point(727, 116);
            this.txtAccountPin.Name = "txtAccountPin";
            this.txtAccountPin.Size = new System.Drawing.Size(121, 20);
            this.txtAccountPin.TabIndex = 128;
            // 
            // txtAccountNum
            // 
            this.txtAccountNum.Location = new System.Drawing.Point(727, 91);
            this.txtAccountNum.Name = "txtAccountNum";
            this.txtAccountNum.Size = new System.Drawing.Size(121, 20);
            this.txtAccountNum.TabIndex = 127;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.SystemColors.Control;
            this.label27.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label27.Location = new System.Drawing.Point(617, 244);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(70, 13);
            this.label27.TabIndex = 126;
            this.label27.Text = "TRANS. TYPE";
            this.label27.Click += new System.EventHandler(this.label27_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.SystemColors.Control;
            this.label26.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label26.Location = new System.Drawing.Point(617, 215);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(56, 13);
            this.label26.TabIndex = 125;
            this.label26.Text = "BALANCE";
            this.label26.Click += new System.EventHandler(this.label26_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.SystemColors.Control;
            this.label25.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label25.Location = new System.Drawing.Point(812, 203);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(24, 10);
            this.label25.TabIndex = 124;
            this.label25.Text = "YEAR";
            this.label25.Click += new System.EventHandler(this.label25_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.SystemColors.Control;
            this.label24.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label24.Location = new System.Drawing.Point(710, 203);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(31, 10);
            this.label24.TabIndex = 123;
            this.label24.Text = "MONTH";
            this.label24.Click += new System.EventHandler(this.label24_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.SystemColors.Control;
            this.label23.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label23.Location = new System.Drawing.Point(761, 203);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(19, 10);
            this.label23.TabIndex = 122;
            this.label23.Text = "DAY";
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.SystemColors.Control;
            this.label22.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label22.Location = new System.Drawing.Point(614, 183);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(64, 13);
            this.label22.TabIndex = 121;
            this.label22.Text = "OPEN DATE";
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.SystemColors.Control;
            this.label21.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label21.Location = new System.Drawing.Point(614, 145);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(57, 13);
            this.label21.TabIndex = 120;
            this.label21.Text = "ACC. TYPE";
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.SystemColors.Control;
            this.label20.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label20.Location = new System.Drawing.Point(614, 119);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(50, 13);
            this.label20.TabIndex = 119;
            this.label20.Text = "ACC. PIN";
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.SystemColors.Control;
            this.label19.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label19.Location = new System.Drawing.Point(614, 94);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(77, 13);
            this.label19.TabIndex = 118;
            this.label19.Text = "ACC. NUMBER";
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // btnCreateAccount
            // 
            this.btnCreateAccount.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCreateAccount.BackgroundImage")));
            this.btnCreateAccount.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCreateAccount.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCreateAccount.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateAccount.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnCreateAccount.Location = new System.Drawing.Point(342, 24);
            this.btnCreateAccount.Name = "btnCreateAccount";
            this.btnCreateAccount.Size = new System.Drawing.Size(96, 34);
            this.btnCreateAccount.TabIndex = 117;
            this.btnCreateAccount.Text = "Create Account";
            this.btnCreateAccount.UseVisualStyleBackColor = true;
            this.btnCreateAccount.Click += new System.EventHandler(this.btnCreateAccount_Click);
            // 
            // btnDisplayCustomers
            // 
            this.btnDisplayCustomers.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDisplayCustomers.BackgroundImage")));
            this.btnDisplayCustomers.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDisplayCustomers.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDisplayCustomers.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisplayCustomers.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDisplayCustomers.Location = new System.Drawing.Point(391, 466);
            this.btnDisplayCustomers.Name = "btnDisplayCustomers";
            this.btnDisplayCustomers.Size = new System.Drawing.Size(96, 34);
            this.btnDisplayCustomers.TabIndex = 116;
            this.btnDisplayCustomers.Text = "Display All Customers";
            this.btnDisplayCustomers.UseVisualStyleBackColor = true;
            this.btnDisplayCustomers.Click += new System.EventHandler(this.btnDisplayCustomers_Click);
            // 
            // btnModify
            // 
            this.btnModify.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnModify.BackgroundImage")));
            this.btnModify.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnModify.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnModify.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModify.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnModify.Location = new System.Drawing.Point(444, 24);
            this.btnModify.Name = "btnModify";
            this.btnModify.Size = new System.Drawing.Size(96, 34);
            this.btnModify.TabIndex = 115;
            this.btnModify.Text = "Modify";
            this.btnModify.UseVisualStyleBackColor = true;
            // 
            // btnSearch
            // 
            this.btnSearch.BackgroundImage = global::Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.Properties.Resources.button_3;
            this.btnSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSearch.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSearch.Location = new System.Drawing.Point(457, 390);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(96, 34);
            this.btnSearch.TabIndex = 114;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnCreateCustomer
            // 
            this.btnCreateCustomer.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCreateCustomer.BackgroundImage")));
            this.btnCreateCustomer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCreateCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCreateCustomer.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateCustomer.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnCreateCustomer.Location = new System.Drawing.Point(240, 24);
            this.btnCreateCustomer.Name = "btnCreateCustomer";
            this.btnCreateCustomer.Size = new System.Drawing.Size(96, 34);
            this.btnCreateCustomer.TabIndex = 113;
            this.btnCreateCustomer.Text = "Create Customer";
            this.btnCreateCustomer.UseVisualStyleBackColor = true;
            this.btnCreateCustomer.Click += new System.EventHandler(this.btnCreateCustomer_Click);
            // 
            // txtBYear
            // 
            this.txtBYear.Location = new System.Drawing.Point(206, 383);
            this.txtBYear.Name = "txtBYear";
            this.txtBYear.Size = new System.Drawing.Size(41, 20);
            this.txtBYear.TabIndex = 112;
            // 
            // txtBMonth
            // 
            this.txtBMonth.Location = new System.Drawing.Point(106, 383);
            this.txtBMonth.Name = "txtBMonth";
            this.txtBMonth.Size = new System.Drawing.Size(38, 20);
            this.txtBMonth.TabIndex = 111;
            // 
            // txtBDay
            // 
            this.txtBDay.Location = new System.Drawing.Point(159, 383);
            this.txtBDay.Name = "txtBDay";
            this.txtBDay.Size = new System.Drawing.Size(34, 20);
            this.txtBDay.TabIndex = 110;
            // 
            // txtStreetName
            // 
            this.txtStreetName.Location = new System.Drawing.Point(156, 269);
            this.txtStreetName.Name = "txtStreetName";
            this.txtStreetName.Size = new System.Drawing.Size(91, 20);
            this.txtStreetName.TabIndex = 109;
            // 
            // txtPostalCode
            // 
            this.txtPostalCode.Location = new System.Drawing.Point(175, 344);
            this.txtPostalCode.Name = "txtPostalCode";
            this.txtPostalCode.Size = new System.Drawing.Size(72, 20);
            this.txtPostalCode.TabIndex = 108;
            // 
            // txtCountry
            // 
            this.txtCountry.Location = new System.Drawing.Point(106, 344);
            this.txtCountry.Name = "txtCountry";
            this.txtCountry.Size = new System.Drawing.Size(63, 20);
            this.txtCountry.TabIndex = 107;
            // 
            // txtState
            // 
            this.txtState.Location = new System.Drawing.Point(215, 306);
            this.txtState.Name = "txtState";
            this.txtState.Size = new System.Drawing.Size(32, 20);
            this.txtState.TabIndex = 106;
            // 
            // txtCity
            // 
            this.txtCity.Location = new System.Drawing.Point(156, 306);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(53, 20);
            this.txtCity.TabIndex = 105;
            // 
            // txtAptoNum
            // 
            this.txtAptoNum.Location = new System.Drawing.Point(106, 306);
            this.txtAptoNum.Name = "txtAptoNum";
            this.txtAptoNum.Size = new System.Drawing.Size(44, 20);
            this.txtAptoNum.TabIndex = 104;
            // 
            // txtStreetNum
            // 
            this.txtStreetNum.Location = new System.Drawing.Point(106, 269);
            this.txtStreetNum.Name = "txtStreetNum";
            this.txtStreetNum.Size = new System.Drawing.Size(44, 20);
            this.txtStreetNum.TabIndex = 103;
            // 
            // txtPhone
            // 
            this.txtPhone.Location = new System.Drawing.Point(147, 243);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(100, 20);
            this.txtPhone.TabIndex = 102;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(147, 217);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(100, 20);
            this.txtEmail.TabIndex = 101;
            // 
            // txtPinCustomer
            // 
            this.txtPinCustomer.Location = new System.Drawing.Point(147, 191);
            this.txtPinCustomer.Name = "txtPinCustomer";
            this.txtPinCustomer.Size = new System.Drawing.Size(100, 20);
            this.txtPinCustomer.TabIndex = 100;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(147, 167);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(100, 20);
            this.txtLastName.TabIndex = 99;
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(147, 141);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(100, 20);
            this.txtname.TabIndex = 98;
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(147, 115);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(100, 20);
            this.txtId.TabIndex = 97;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label18.Location = new System.Drawing.Point(213, 408);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(24, 10);
            this.label18.TabIndex = 96;
            this.label18.Text = "YEAR";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label17.Location = new System.Drawing.Point(113, 408);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(31, 10);
            this.label17.TabIndex = 95;
            this.label17.Text = "MONTH";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label16.Location = new System.Drawing.Point(168, 408);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(19, 10);
            this.label16.TabIndex = 94;
            this.label16.Text = "DAY";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label15.Location = new System.Drawing.Point(38, 386);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(55, 13);
            this.label15.TabIndex = 93;
            this.label15.Text = "BIRTHDAY";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label14.Location = new System.Drawing.Point(179, 366);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 10);
            this.label14.TabIndex = 92;
            this.label14.Text = "POSTAL CODE";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label13.Location = new System.Drawing.Point(114, 366);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(39, 10);
            this.label13.TabIndex = 91;
            this.label13.Text = "COUNTRY";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label12.Location = new System.Drawing.Point(204, 329);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 10);
            this.label12.TabIndex = 90;
            this.label12.Text = "PROVINCE";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label11.Location = new System.Drawing.Point(173, 330);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(20, 10);
            this.label11.TabIndex = 89;
            this.label11.Text = "CITY";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label10.Location = new System.Drawing.Point(114, 330);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(30, 10);
            this.label10.TabIndex = 88;
            this.label10.Text = "APTO #";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label9.Location = new System.Drawing.Point(173, 292);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 10);
            this.label9.TabIndex = 87;
            this.label9.Text = "STREET NAME";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.Location = new System.Drawing.Point(107, 292);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(39, 10);
            this.label8.TabIndex = 86;
            this.label8.Text = "STREET #";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(37, 273);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 13);
            this.label7.TabIndex = 85;
            this.label7.Text = "ADDRESS";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Location = new System.Drawing.Point(37, 247);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 13);
            this.label6.TabIndex = 84;
            this.label6.Text = "PHONE NUMBER";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(36, 221);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 13);
            this.label5.TabIndex = 83;
            this.label5.Text = "EMAIL";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(37, 194);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 13);
            this.label4.TabIndex = 82;
            this.label4.Text = "PIN";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(36, 170);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 13);
            this.label3.TabIndex = 81;
            this.label3.Text = "LAST NAME";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(36, 145);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 80;
            this.label2.Text = "NAME";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(37, 119);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(17, 13);
            this.label1.TabIndex = 79;
            this.label1.Text = "ID";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.SystemColors.Control;
            this.label39.Font = new System.Drawing.Font("Bahnschrift", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label39.Location = new System.Drawing.Point(751, 262);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(98, 13);
            this.label39.TabIndex = 157;
            this.label39.Text = "Select Transaction";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.SystemColors.Control;
            this.label29.Font = new System.Drawing.Font("Bahnschrift", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label29.Location = new System.Drawing.Point(769, 163);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(79, 13);
            this.label29.TabIndex = 158;
            this.label29.Text = "Select Account";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.SystemColors.Control;
            this.label36.Font = new System.Drawing.Font("Bahnschrift", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label36.Location = new System.Drawing.Point(740, 304);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(109, 13);
            this.label36.TabIndex = 159;
            this.label36.Text = "Select Checking Type";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.SystemColors.Control;
            this.label37.Font = new System.Drawing.Font("Bahnschrift", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label37.Location = new System.Drawing.Point(745, 345);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(104, 13);
            this.label37.TabIndex = 159;
            this.label37.Text = "Select Savings Type";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.SystemColors.Control;
            this.label38.Font = new System.Drawing.Font("Bahnschrift", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label38.Location = new System.Drawing.Point(753, 382);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(95, 13);
            this.label38.TabIndex = 159;
            this.label38.Text = "Select Credit Type";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.SystemColors.Control;
            this.label40.Font = new System.Drawing.Font("Bahnschrift", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label40.Location = new System.Drawing.Point(732, 420);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(118, 13);
            this.label40.TabIndex = 159;
            this.label40.Text = "Select Credit Category";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label41.Location = new System.Drawing.Point(145, 386);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(11, 13);
            this.label41.TabIndex = 93;
            this.label41.Text = "/";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label42.Location = new System.Drawing.Point(194, 386);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(11, 13);
            this.label42.TabIndex = 93;
            this.label42.Text = "/";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label43.Location = new System.Drawing.Point(743, 184);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(11, 13);
            this.label43.TabIndex = 93;
            this.label43.Text = "/";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label44.Location = new System.Drawing.Point(794, 183);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(11, 13);
            this.label44.TabIndex = 93;
            this.label44.Text = "/";
            // 
            // FortisBankForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.Properties.Resources._5_FINAL;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(878, 527);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.btnReadFile);
            this.Controls.Add(this.btnWriteFile);
            this.Controls.Add(this.cboCredCateg);
            this.Controls.Add(this.cboCredType);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.cboSavingType);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.btnDisplayAllAcc);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.lstCustomer);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.cboCheckingType);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.txtSearchBox);
            this.Controls.Add(this.btnSaveCustomer);
            this.Controls.Add(this.btnSaveAccount);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.listViewAccount);
            this.Controls.Add(this.cboTransaction);
            this.Controls.Add(this.txtBalance);
            this.Controls.Add(this.txtAccYear);
            this.Controls.Add(this.txtAcMonth);
            this.Controls.Add(this.txtADay);
            this.Controls.Add(this.cboAccountType);
            this.Controls.Add(this.txtAccountPin);
            this.Controls.Add(this.txtAccountNum);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.btnCreateAccount);
            this.Controls.Add(this.btnDisplayCustomers);
            this.Controls.Add(this.btnModify);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnCreateCustomer);
            this.Controls.Add(this.txtBYear);
            this.Controls.Add(this.txtBMonth);
            this.Controls.Add(this.txtBDay);
            this.Controls.Add(this.txtStreetName);
            this.Controls.Add(this.txtPostalCode);
            this.Controls.Add(this.txtCountry);
            this.Controls.Add(this.txtState);
            this.Controls.Add(this.txtCity);
            this.Controls.Add(this.txtAptoNum);
            this.Controls.Add(this.txtStreetNum);
            this.Controls.Add(this.txtPhone);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtPinCustomer);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Name = "FortisBankForm";
            this.Text = "FortisBankForm";
            this.Load += new System.EventHandler(this.FortisBankForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnReadFile;
        private System.Windows.Forms.Button btnWriteFile;
        private System.Windows.Forms.ComboBox cboCredCateg;
        private System.Windows.Forms.ComboBox cboCredType;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.ComboBox cboSavingType;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button btnDisplayAllAcc;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.ListView lstCustomer;
        private System.Windows.Forms.ColumnHeader lstCustId;
        private System.Windows.Forms.ColumnHeader lstCusFn;
        private System.Windows.Forms.ColumnHeader LstCusLn;
        private System.Windows.Forms.ColumnHeader lstCustPin;
        private System.Windows.Forms.ColumnHeader lstCustEmail;
        private System.Windows.Forms.ColumnHeader lstCustPhone;
        private System.Windows.Forms.ColumnHeader lstCusStNum;
        private System.Windows.Forms.ColumnHeader lstCustStName;
        private System.Windows.Forms.ColumnHeader lstCustApto;
        private System.Windows.Forms.ColumnHeader lstCustCity;
        private System.Windows.Forms.ColumnHeader lstCustState;
        private System.Windows.Forms.ColumnHeader lstCustCountry;
        private System.Windows.Forms.ColumnHeader lstCustPostal;
        private System.Windows.Forms.ColumnHeader lstCustBDay;
        private System.Windows.Forms.ColumnHeader lstCustBMonth;
        private System.Windows.Forms.ColumnHeader lstCustBYear;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.ComboBox cboCheckingType;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtSearchBox;
        private System.Windows.Forms.Button btnSaveCustomer;
        private System.Windows.Forms.Button btnSaveAccount;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ListView listViewAccount;
        private System.Windows.Forms.ColumnHeader lstAccNumber;
        private System.Windows.Forms.ColumnHeader lstAcPin;
        private System.Windows.Forms.ColumnHeader lstAcType;
        private System.Windows.Forms.ColumnHeader lstAccDay;
        private System.Windows.Forms.ColumnHeader lstAcMonth;
        private System.Windows.Forms.ColumnHeader lstAcYear;
        private System.Windows.Forms.ColumnHeader lstAcBalance;
        private System.Windows.Forms.ColumnHeader lstAccTrans;
        private System.Windows.Forms.ComboBox cboTransaction;
        private System.Windows.Forms.TextBox txtBalance;
        private System.Windows.Forms.TextBox txtAccYear;
        private System.Windows.Forms.TextBox txtAcMonth;
        private System.Windows.Forms.TextBox txtADay;
        private System.Windows.Forms.ComboBox cboAccountType;
        private System.Windows.Forms.TextBox txtAccountPin;
        private System.Windows.Forms.TextBox txtAccountNum;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnCreateAccount;
        private System.Windows.Forms.Button btnDisplayCustomers;
        private System.Windows.Forms.Button btnModify;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnCreateCustomer;
        private System.Windows.Forms.TextBox txtBYear;
        private System.Windows.Forms.TextBox txtBMonth;
        private System.Windows.Forms.TextBox txtBDay;
        private System.Windows.Forms.TextBox txtStreetName;
        private System.Windows.Forms.TextBox txtPostalCode;
        private System.Windows.Forms.TextBox txtCountry;
        private System.Windows.Forms.TextBox txtState;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.TextBox txtAptoNum;
        private System.Windows.Forms.TextBox txtStreetNum;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtPinCustomer;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
    }
}