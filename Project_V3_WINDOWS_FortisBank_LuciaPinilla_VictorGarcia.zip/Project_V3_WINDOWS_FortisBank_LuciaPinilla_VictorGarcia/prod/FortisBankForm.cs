﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.bus;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.prod
{
    public partial class FortisBankForm : Form
    {

        DataAccess myCollection = new DataAccess();
        //DataAccess myCollectionsFromFile = new DataAccess();

        FortisBank theBank = new FortisBank();
        int index = 0;
        static String myFile = @"../../data/Bikes.bin";
        public FortisBankForm()
        {
            InitializeComponent();
        }
        private void activateControls(bool enCreateCustomer, bool enSaveCustomer, bool enBtnDisplaAllCustomers, bool enBtnModify, bool enRadCustomer
                                        , bool enRadAccount, bool enBtnSearch, bool enTxtSearch,
                                        bool enTxtId, bool enTxtName, bool enTxtLn, bool enTxtPinCus, bool entxtEmail, bool enTxtPhone,
                                        bool enTxtStreetNum, bool enTxtStreetName, bool enApto, bool enTxtCity, bool enTxtState, bool enTxtCountry, bool enTxtPostal,
                                        bool entxtBDay, bool enTxtBmonth, bool enTxtBYear,
                                        bool enTxtAccNum, bool enTxtAccPin, bool enAccType, bool entxtODay, bool enTxtOMonth, bool enTxtOYear, bool enTxtBalance, bool enTransType
                                        , bool enBtnCreateAcc, bool enBtnSaveAcc, bool enChekingType)


        {
            btnCreateCustomer.Enabled = enCreateCustomer;
            btnSaveCustomer.Enabled = enSaveCustomer;
            btnDisplayCustomers.Enabled = enBtnDisplaAllCustomers;
            btnModify.Enabled = enBtnModify;
            //radAccount.Enabled = enRadAccount;
            //radCustomer.Enabled = enRadCustomer;
            btnSearch.Enabled = enBtnSearch;
            txtSearchBox.Enabled = enTxtSearch;

            txtId.Enabled = enTxtId;
            txtname.Enabled = enTxtName;
            txtLastName.Enabled = enTxtLn;
            txtPinCustomer.Enabled = enTxtPinCus;
            txtEmail.Enabled = entxtEmail;
            txtPhone.Enabled = enTxtPhone;
            txtStreetNum.Enabled = enTxtStreetNum;
            txtStreetName.Enabled = enTxtStreetName;
            txtAptoNum.Enabled = enApto;
            txtCity.Enabled = enTxtCity;
            txtState.Enabled = enTxtState;
            txtCountry.Enabled = enTxtCountry;
            txtPostalCode.Enabled = enTxtPostal;
            txtBDay.Enabled = entxtBDay;
            txtBMonth.Enabled = enTxtBmonth;
            txtBYear.Enabled = enTxtBYear;

            txtAccountNum.Enabled = enTxtAccNum;
            txtAccountPin.Enabled = enTxtAccPin;
            cboAccountType.Enabled = enAccType;
            txtADay.Enabled = entxtODay;
            txtAcMonth.Enabled = enTxtOMonth;
            txtAccYear.Enabled = enTxtOYear;
            txtBalance.Enabled = enTxtBalance;
            cboTransaction.Enabled = enTransType;
            btnSaveAccount.Enabled = enBtnSaveAcc;
            btnCreateAccount.Enabled = enBtnCreateAcc;
            cboCheckingType.Enabled = enChekingType;

        }
        private void FortisBankForm_Load(object sender, EventArgs e)
        {

            activateControls(true, false, true, false, true, true, true, true, false, false, false, false, false, false, false, false, false, false, false, false,
                false, false, false, false, false, false, false, false, false, false, false, false, true, false, false);

            foreach (EnumAccType element in Enum.GetValues(typeof(EnumAccType)))
            {
                cboAccountType.Items.Add(element);
                cboAccountType.Text = Convert.ToString(cboAccountType.Items[0]);
            }

            foreach (EnumTransType element in Enum.GetValues(typeof(EnumTransType)))
            {
                cboTransaction.Items.Add(element);
                cboTransaction.Text = Convert.ToString(cboTransaction.Items[0]);
            }

            foreach (EnumCheckingType element in Enum.GetValues(typeof(EnumCheckingType)))
            {
                cboCheckingType.Items.Add(element);
                cboCheckingType.Text = Convert.ToString(cboCheckingType.Items[0]);
            }

            foreach (EnumSavingsType element in Enum.GetValues(typeof(EnumSavingsType)))
            {
                cboSavingType.Items.Add(element);
                cboSavingType.Text = Convert.ToString(cboSavingType.Items[0]);
            }

            foreach (EnumCreditType element in Enum.GetValues(typeof(EnumCreditType)))
            {
                cboCredType.Items.Add(element);
                cboCredType.Text = Convert.ToString(cboCredType.Items[0]);
            }

            foreach (EnumCreditCategory element in Enum.GetValues(typeof(EnumCreditCategory)))
            {
                cboCredCateg.Items.Add(element);
                cboCredCateg.Text = Convert.ToString(cboCredCateg.Items[0]);
            }


        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            Customer aCust;
            aCust = theBank.CreateCustomer();
            bool found = false;

            foreach (Customer item in myCollection.CustomersList)
            {
                if (item.Id == Convert.ToInt32(txtSearchBox.Text))
                {
                    found = true;
                    aCust = item;
                }
            }
            if (found == true)
            {
                MessageBox.Show("Customer : " + aCust.Id + "name : " + aCust.Fn + " found!!");
            }
            else { MessageBox.Show("Customer NOT found "); }

            txtId.Text = Convert.ToString(aCust.Id);
            txtname.Text = aCust.Fn;
            txtLastName.Text = aCust.Ln;
            txtPinCustomer.Text = Convert.ToString(aCust.Pin);
            txtEmail.Text = aCust.Email;
            txtStreetNum.Text = Convert.ToString(aCust.Address.StrNum);
            txtStreetName.Text = aCust.Address.StrName;
            txtAptoNum.Text = Convert.ToString(aCust.Address.AptNum);
            txtCity.Text = aCust.Address.City;
            txtState.Text = aCust.Address.Province;
            txtCountry.Text = aCust.Address.Country;
            txtPostalCode.Text = aCust.Address.ZipCode;
            ;
            foreach (Account element in aCust.MyAccounts)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(element.AccNumber));

                item.SubItems.Add(Convert.ToString(element.AccPin));
                item.SubItems.Add(Convert.ToString(element.AccountType));
                item.SubItems.Add(Convert.ToString(element.OpenDate.Day));
                item.SubItems.Add(Convert.ToString(element.OpenDate.Month));
                item.SubItems.Add(Convert.ToString(element.OpenDate.Year));
                item.SubItems.Add(Convert.ToString(element.AvailableBalance));
                item.SubItems.Add(Convert.ToString(element.TransType));




                this.listViewAccount.Items.Add(item);

            }
        }

        private void btnCreateCustomer_Click(object sender, EventArgs e)
        {
            activateControls(false, true, false, false, false, false, false, false, true, true, true, true, true,
                            true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, false, false, true);
        }

        private void btnSaveCustomer_Click(object sender, EventArgs e)
        {
            Customer aCust;

            aCust = theBank.CreateCustomer();
            aCust.Id = Convert.ToInt32(txtId.Text);
            aCust.Fn = txtname.Text;
            aCust.Ln = txtLastName.Text;
            aCust.Phone = txtPhone.Text;
            aCust.Pin = Convert.ToInt32(txtPinCustomer.Text);
            aCust.Email = txtEmail.Text;
            aCust.Address.StrNum = Convert.ToInt32(txtStreetNum.Text); ;
            aCust.Address.StrName = txtStreetName.Text;
            aCust.Address.AptNum = Convert.ToInt32(txtAptoNum.Text); ;
            aCust.Address.City = txtCity.Text;
            aCust.Address.Province = txtState.Text;
            aCust.Address.Country = txtCountry.Text;
            aCust.Address.ZipCode = txtPostalCode.Text;
            aCust.BirthDate.Day = Convert.ToInt32(txtBDay.Text);
            aCust.BirthDate.Month = Convert.ToInt32(txtBMonth.Text);
            aCust.BirthDate.Year = Convert.ToInt32(txtBYear.Text);

            Checking anAcc = new Checking();
            anAcc.AccNumber = Convert.ToInt64(txtAccountNum.Text);
            anAcc.AccountType = (EnumAccType)cboAccountType.SelectedIndex;
            anAcc.AccPin = Convert.ToInt32(txtPinCustomer.Text);
            anAcc.OpenDate.Day = Convert.ToInt32(txtADay.Text);
            anAcc.OpenDate.Month = Convert.ToInt32(txtAcMonth.Text);
            anAcc.OpenDate.Year = Convert.ToInt32(txtAccYear.Text);
            anAcc.AvailableBalance = 0.00;
            anAcc.TransType = (EnumTransType)cboTransaction.SelectedItem;
            anAcc.TransCounter++;
            anAcc.ExtraFees = 2;
            anAcc.CType = (EnumCheckingType)cboCheckingType.SelectedItem;

            aCust.MyAccounts.Add(anAcc);
            myCollection.AccountsList.Add(anAcc);
            myCollection.CustomersList.Add(aCust);

            activateControls(true, false, true, false, true, true, true, true, false, false, false, false, false, false,
                false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
                false, false, true, true, false);
            Reset();
        }
        void Reset()
        {
            txtId.Text = "";
            txtname.Text = "";
            txtLastName.Text = "";
            txtPinCustomer.Text = "";
            txtEmail.Text = "";
            txtPhone.Text = "";
            txtStreetNum.Text = "";
            txtStreetName.Text = "";
            txtAptoNum.Text = "";
            txtCity.Text = "";
            txtState.Text = "";
            txtCountry.Text = "";
            txtPostalCode.Text = "";
            txtBDay.Text = "";
            txtBMonth.Text = "";
            txtBYear.Text = "";
            txtAccountNum.Text = "";
            txtAccountPin.Text = "";
            cboAccountType.Text = Convert.ToString(cboAccountType.Items[0]);
            txtADay.Text = "";
            txtAcMonth.Text = "";
            txtAccYear.Text = "";
            txtBalance.Text = "";
            cboCheckingType.Text = Convert.ToString(cboCheckingType.Items[0]);
            this.listViewAccount.Items.Clear();
           // this.listViewTransaction.Items.Clear();
            this.lstCustomer.Items.Clear();
        }

        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            activateControls(false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
                false, false, false, false, false, false, true, true, true, true, true, true, true, true, false, true, true);

        }

        private void btnSaveAccount_Click(object sender, EventArgs e)
        {
            Customer aCust;
            aCust = theBank.CreateCustomer();
            bool found = false;

            foreach (Customer item in myCollection.CustomersList)
            {
                if (item.Id == Convert.ToInt32(txtId.Text))
                {

                    aCust = item;

                    if (cboAccountType.SelectedIndex == 1)
                    {
                        Checking anAcc = new Checking();
                        anAcc.AccNumber = Convert.ToInt64(txtAccountNum.Text);
                        anAcc.AccountType = (EnumAccType)cboAccountType.SelectedIndex;
                        anAcc.AccPin = Convert.ToInt32(txtPinCustomer.Text);
                        anAcc.OpenDate.Day = Convert.ToInt32(txtADay.Text);
                        anAcc.OpenDate.Month = Convert.ToInt32(txtAcMonth.Text);
                        anAcc.OpenDate.Year = Convert.ToInt32(txtAccYear.Text);
                        anAcc.AvailableBalance = 0.00;
                        anAcc.TransType = (EnumTransType)cboTransaction.SelectedItem;
                        anAcc.TransCounter++;
                        anAcc.ExtraFees = 2;
                        anAcc.CType = (EnumCheckingType)cboCheckingType.SelectedItem;
                        aCust.MyAccounts.Add(anAcc);


                    }

                    else if (cboAccountType.SelectedIndex == 3)
                    {
                        Savings anAcc = new Savings();
                        anAcc.AccNumber = Convert.ToInt64(txtAccountNum.Text);
                        anAcc.AccountType = (EnumAccType)cboAccountType.SelectedIndex;
                        anAcc.AccPin = Convert.ToInt32(txtPinCustomer.Text);
                        anAcc.OpenDate.Day = Convert.ToInt32(txtADay.Text);
                        anAcc.OpenDate.Month = Convert.ToInt32(txtAcMonth.Text);
                        anAcc.OpenDate.Year = Convert.ToInt32(txtAccYear.Text);
                        anAcc.AvailableBalance = 0.00;
                        anAcc.TransType = (EnumTransType)cboTransaction.SelectedItem;
                        anAcc.SType = (EnumSavingsType)cboSavingType.SelectedItem;
                        aCust.MyAccounts.Add(anAcc);

                    }

                    else if (cboAccountType.SelectedIndex == 2)
                    {
                        Credit anAcc = new Credit();
                        anAcc.AccNumber = Convert.ToInt64(txtAccountNum.Text);
                        anAcc.AccountType = (EnumAccType)cboAccountType.SelectedIndex;
                        anAcc.AccPin = Convert.ToInt32(txtPinCustomer.Text);
                        anAcc.OpenDate.Day = Convert.ToInt32(txtADay.Text);
                        anAcc.OpenDate.Month = Convert.ToInt32(txtAcMonth.Text);
                        anAcc.OpenDate.Year = Convert.ToInt32(txtAccYear.Text);
                        anAcc.AvailableBalance = 0.00;
                        anAcc.TransType = (EnumTransType)cboTransaction.SelectedItem;
                        anAcc.CreditType = (EnumCreditType)cboCredType.SelectedItem;
                        anAcc.CreditCategory = (EnumCreditCategory)cboCredCateg.SelectedItem;
                        aCust.MyAccounts.Add(anAcc);

                    }
                }
            }


        }
        private void btnDisplayAllAcc_Click(object sender, EventArgs e)
        {
            this.Close();
            //DisplayallAccounts();
        }
        void DisplayallAccounts()
        {

            foreach (Account element in this.myCollection.AccountsList)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(element.AccNumber));

                item.SubItems.Add(Convert.ToString(element.AccPin));
                item.SubItems.Add(Convert.ToString(element.AccountType));
                item.SubItems.Add(Convert.ToString(element.OpenDate.Day));
                item.SubItems.Add(Convert.ToString(element.OpenDate.Month));
                item.SubItems.Add(Convert.ToString(element.OpenDate.Year));
                item.SubItems.Add(Convert.ToString(element.AvailableBalance));
                item.SubItems.Add(Convert.ToString(element.TransType));




                this.listViewAccount.Items.Add(item);

            }

            



        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            Reset();
        }

       

        private void btnDisplayCustomers_Click(object sender, EventArgs e)
        {
            foreach (Customer element in this.myCollection.CustomersList)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(element.Id));

                item.SubItems.Add(Convert.ToString(element.Fn));
                item.SubItems.Add(Convert.ToString(element.Ln));
                item.SubItems.Add(Convert.ToString(element.Pin));
                item.SubItems.Add(Convert.ToString(element.Email));
                item.SubItems.Add(Convert.ToString(element.Phone));
                item.SubItems.Add(Convert.ToString(element.Address.StrNum));
                item.SubItems.Add(Convert.ToString(element.Address.StrName));
                item.SubItems.Add(Convert.ToString(element.Address.AptNum));
                item.SubItems.Add(Convert.ToString(element.Address.City));
                item.SubItems.Add(Convert.ToString(element.Address.Province));
                item.SubItems.Add(Convert.ToString(element.Address.Country));
                item.SubItems.Add(Convert.ToString(element.Address.ZipCode));





                this.lstCustomer.Items.Add(item);

            }

            foreach (Customer element in this.myCollection.CustomersList)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(element.Id));

                item.SubItems.Add(Convert.ToString(element.Fn));
                item.SubItems.Add(Convert.ToString(element.Ln));
                item.SubItems.Add(Convert.ToString(element.Pin));
                item.SubItems.Add(Convert.ToString(element.Email));
                item.SubItems.Add(Convert.ToString(element.Phone));
                item.SubItems.Add(Convert.ToString(element.Address.StrNum));
                item.SubItems.Add(Convert.ToString(element.Address.StrName));
                item.SubItems.Add(Convert.ToString(element.Address.AptNum));
                item.SubItems.Add(Convert.ToString(element.Address.City));
                item.SubItems.Add(Convert.ToString(element.Address.Province));
                item.SubItems.Add(Convert.ToString(element.Address.Country));
                item.SubItems.Add(Convert.ToString(element.Address.ZipCode));





                this.lstCustomer.Items.Add(item);

            }

        }

        private void btnWriteFile_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream(myFile, FileMode.OpenOrCreate, FileAccess.Write);
            BinaryFormatter writer = new BinaryFormatter();
            writer.Serialize(fs, myCollection.CustomersList);
            
            fs.Close();
            MessageBox.Show("The Bank information has been saved");

        }

        private void btnReadFile_Click(object sender, EventArgs e)
        {
            if (File.Exists(myFile))
            {
                FileStream fs = new FileStream(myFile, FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                myCollection.CustomersList = (List<Customer>)bin.Deserialize(fs);


                fs.Close();


            }
        }

        private void lstCustomer_SelectedIndexChanged(object sender, EventArgs e)
        {
            index = lstCustomer.FocusedItem.Index;
            foreach (Customer record in myCollection.CustomersList)
            {
                txtId.Text = Convert.ToString(myCollection.CustomersList[index].Id);
                txtname.Text = Convert.ToString(myCollection.CustomersList[index].Fn);
                txtLastName.Text = Convert.ToString(myCollection.CustomersList[index].Ln);
                txtPinCustomer.Text = Convert.ToString(myCollection.CustomersList[index].Pin);
                txtEmail.Text = Convert.ToString(myCollection.CustomersList[index].Email);
                txtPhone.Text = Convert.ToString(myCollection.CustomersList[index].Phone);
                txtStreetNum.Text = Convert.ToString(myCollection.CustomersList[index].Address.StrNum);
                txtStreetName.Text = Convert.ToString(myCollection.CustomersList[index].Address.StrName);
                txtAptoNum.Text = Convert.ToString(myCollection.CustomersList[index].Address.AptNum);
                txtCity.Text = Convert.ToString(myCollection.CustomersList[index].Address.City);
                txtState.Text = Convert.ToString(myCollection.CustomersList[index].Address.Province);
                txtCountry.Text = Convert.ToString(myCollection.CustomersList[index].Address.Country);
                txtPostalCode.Text = Convert.ToString(myCollection.CustomersList[index].Address.ZipCode);
                txtBDay.Text = Convert.ToString(myCollection.CustomersList[index].BirthDate.Day);
                txtBMonth.Text = Convert.ToString(myCollection.CustomersList[index].BirthDate.Month);
                txtBYear.Text = Convert.ToString(myCollection.CustomersList[index].BirthDate.Year);

                //Customer acust2 = new Customer();
                //acust2.MyAccounts = myCollection.CustomersList[index].MyAccounts;

                foreach (Account element in myCollection.CustomersList[index].MyAccounts)
                {
                    ListViewItem item = new ListViewItem(Convert.ToString(element.AccNumber));

                    item.SubItems.Add(Convert.ToString(element.AccPin));
                    item.SubItems.Add(Convert.ToString(element.AccountType));
                    item.SubItems.Add(Convert.ToString(element.OpenDate.Day));
                    item.SubItems.Add(Convert.ToString(element.OpenDate.Month));
                    item.SubItems.Add(Convert.ToString(element.OpenDate.Year));
                    item.SubItems.Add(Convert.ToString(element.AvailableBalance));
                    item.SubItems.Add(Convert.ToString(element.TransType));




                    this.listViewAccount.Items.Add(item);

                }


            }
        }

        private void listViewAccount_SelectedIndexChanged(object sender, EventArgs e)
        {
            index = listViewAccount.FocusedItem.Index;

            foreach (Account element in myCollection.AccountsList)
            {
                txtAccountNum.Text = Convert.ToString(myCollection.AccountsList[index].AccNumber);
                txtAccountPin.Text = Convert.ToString(myCollection.AccountsList[index].AccPin);
                cboAccountType.Text = Convert.ToString(myCollection.AccountsList[index].AccountType);
                txtADay.Text = Convert.ToString(myCollection.AccountsList[index].OpenDate.Day);
                txtAcMonth.Text = Convert.ToString(myCollection.AccountsList[index].OpenDate.Month);
                txtAccYear.Text = Convert.ToString(myCollection.AccountsList[index].OpenDate.Year);
                txtBalance.Text = Convert.ToString(myCollection.AccountsList[index].AvailableBalance);
                cboTransaction.Text = Convert.ToString(myCollection.AccountsList[index].TransType);
            }
        }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void label22_Click(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void label23_Click(object sender, EventArgs e)
        {

        }

        private void label24_Click(object sender, EventArgs e)
        {

        }

        private void label25_Click(object sender, EventArgs e)
        {

        }

        private void label26_Click(object sender, EventArgs e)
        {

        }

        private void label27_Click(object sender, EventArgs e)
        {

        }

        private void label28_Click(object sender, EventArgs e)
        {

        }
    }
}
