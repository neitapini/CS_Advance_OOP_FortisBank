﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.bus
{
    [Serializable]
    public class Savings : Account
    {
        private const double annualIntRate = Rates.savingAccountRate;
        private const double extraFees = 3.0;
        private EnumSavingsType sType;

        //public double AnnualIntRate { get => annualIntRate; set => annualIntRate = value; }
        //public double AnnualGain { get => annualGain; set => annualGain = value; }
        //public double ExtraFees { get => extraFees; set => extraFees = value; }
        public EnumSavingsType SType { get => sType; set => sType = value; }

        public Savings()
        {
            //this.AnnualIntRate = 0.00;
            //this.AnnualGain = 0.00;
            //this.ExtraFees = 0.00;
            
            this.SType = EnumSavingsType.undefined;
        }
        //public Savings(double annualIntRate, double annualGain, double extraFees)
        //{
            //this.AnnualIntRate = annualIntRate;
           // this.AnnualGain = annualGain;
            //this.ExtraFees = extraFees;
       // }
        public Savings(EnumSavingsType sType)
        {
            //this.AnnualIntRate = annualIntRate;
            //this.AnnualGain = annualGain;
            //this.ExtraFees = extraFees;
            this.SType = sType;
        }

        override
        public String ToString()
        {
            return  base.ToString() + " - " + 
                //this.AnnualIntRate + " - " + 
                //this.AnnualGain + " - " + 
                //this.ExtraFees + " - " + 
                this.SType + " - " +
                MakeTransaction();
        }
        override
        public double MakeTransaction()
        {
            //Because the only tranExtraFees = 3.00;
            Transaction aTrans = new Transaction();
            if (base.TransType == EnumTransType.withdraw || base.TransType == EnumTransType.payment || base.TransType == EnumTransType.transfer)
            { return base.AvailableBalance - aTrans.Amount - extraFees;}
            else if (base.TransType == EnumTransType.deposit)
            { return base.AvailableBalance + aTrans.Amount; }
            else
            { return base.AvailableBalance;}
            
        }
    }
}
