﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.bus;

namespace Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.data
{
    public class FileHandler
    {
        private static String filePath = @"..\..\data\theBankMovements.ser";

        public static void WriteToFile(List<Account> anAccList)
        {
            //foreach (Account element in anAccList)
            //{
            //    string[] line = new string[anAccList.Count];

            //    if (element is Savings)
            //    {
            //        for (int i = 0; i < anAccList.Count; i++)
            //        {
            //            line[i] = anAccList[i].AccNumber + "|" +
            //                    anAccList[i].AccPin + "|" +
            //                    anAccList[i].AccountType + "|" +
            //                    anAccList[i].OpenDate.Day + "|" +
            //                    anAccList[i].OpenDate.Month + "|" +
            //                    anAccList[i].OpenDate.Year + "|" +
            //                    anAccList[i].AvailableBalance + "|" +
            //                    anAccList[i].Amount + "|" +
            //                    anAccList[i].;
            //        }



            //    }

            //}
            FileStream fs = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Write);
            BinaryFormatter writer = new BinaryFormatter();
            writer.Serialize(fs, anAccList);
            fs.Close();


        }
        public static void WriteToFile(List<Customer> aCustomerList)
        {
            FileStream fs = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Write);
            BinaryFormatter writer = new BinaryFormatter();
            writer.Serialize(fs, aCustomerList);
            fs.Close();
        }
        public static void WriteToFile(List<Transaction> aTransactionList)
        {
            FileStream fs = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Write);
            BinaryFormatter writer = new BinaryFormatter();
            writer.Serialize(fs, aTransactionList);
            fs.Close();
        }
        public static List<Account> ReadFromAccountFile()
        {
            List<Account> anAccList = new List<Account>();
            if (File.Exists(filePath))
            {
                FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                anAccList = (List<Account>)bin.Deserialize(fs);

                return anAccList;
            }
            else
            {
                Console.WriteLine("File does not exists\n");
                return null;
            }
        }
        public static List<Customer> ReadFromCutomerFile()
        {
            List<Customer> aCustomerList = new List<Customer>();
            if (File.Exists(filePath))
            {
                FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                aCustomerList = (List<Customer>)bin.Deserialize(fs);

                return aCustomerList;
            }
            else
            {
                Console.WriteLine("File does not exists\n");
                return null;
            }

        }
      
        public static List<Transaction> ReadFromTransactionFile()
        {
            List<Transaction> aTransactionList = new List<Transaction>();
            if (File.Exists(filePath))
            {
                FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                aTransactionList = (List<Transaction>)bin.Deserialize(fs);

                return aTransactionList;
            }
            else
            {
                Console.WriteLine("File does not exists\n");
                return null;
            }

        }
        
}
}
