﻿namespace Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.prod
{
    partial class InitialForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonManager = new System.Windows.Forms.Button();
            this.buttonCustomer = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonManager
            // 
            this.buttonManager.BackgroundImage = global::Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.Properties.Resources.botton;
            this.buttonManager.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonManager.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonManager.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonManager.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonManager.Location = new System.Drawing.Point(57, 131);
            this.buttonManager.Name = "buttonManager";
            this.buttonManager.Size = new System.Drawing.Size(116, 36);
            this.buttonManager.TabIndex = 0;
            this.buttonManager.Text = "Manager";
            this.buttonManager.UseVisualStyleBackColor = true;
            this.buttonManager.Click += new System.EventHandler(this.buttonManager_Click);
            // 
            // buttonCustomer
            // 
            this.buttonCustomer.BackgroundImage = global::Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.Properties.Resources.botton;
            this.buttonCustomer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonCustomer.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCustomer.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonCustomer.Location = new System.Drawing.Point(221, 131);
            this.buttonCustomer.Name = "buttonCustomer";
            this.buttonCustomer.Size = new System.Drawing.Size(127, 36);
            this.buttonCustomer.TabIndex = 1;
            this.buttonCustomer.Text = "Customer";
            this.buttonCustomer.UseVisualStyleBackColor = true;
            this.buttonCustomer.Click += new System.EventHandler(this.buttonCustomer_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.LightSeaGreen;
            this.label1.Font = new System.Drawing.Font("Bahnschrift SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(53, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 19);
            this.label1.TabIndex = 2;
            this.label1.Text = "You Are? ";
            // 
            // InitialForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.Properties.Resources.WwlcomeForm;
            this.ClientSize = new System.Drawing.Size(401, 250);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonCustomer);
            this.Controls.Add(this.buttonManager);
            this.Name = "InitialForm";
            this.Text = "InitialForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonManager;
        private System.Windows.Forms.Button buttonCustomer;
        private System.Windows.Forms.Label label1;
    }
}