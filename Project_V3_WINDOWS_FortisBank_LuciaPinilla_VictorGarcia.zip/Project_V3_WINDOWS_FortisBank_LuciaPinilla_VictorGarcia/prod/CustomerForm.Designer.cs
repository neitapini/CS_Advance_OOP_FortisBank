﻿namespace Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia
{
    partial class CustomerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewGroup listViewGroup1 = new System.Windows.Forms.ListViewGroup("ListViewGroup", System.Windows.Forms.HorizontalAlignment.Left);
            System.Windows.Forms.ListViewGroup listViewGroup2 = new System.Windows.Forms.ListViewGroup("ListViewGroup", System.Windows.Forms.HorizontalAlignment.Left);
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomerForm));
            this.textBoxBYear = new System.Windows.Forms.TextBox();
            this.textBoxBDay = new System.Windows.Forms.TextBox();
            this.textBoxBMonth = new System.Windows.Forms.TextBox();
            this.textBoxStrName = new System.Windows.Forms.TextBox();
            this.textBoxZipCode = new System.Windows.Forms.TextBox();
            this.textBoxCountry = new System.Windows.Forms.TextBox();
            this.textBoxProvince = new System.Windows.Forms.TextBox();
            this.textBoxCity = new System.Windows.Forms.TextBox();
            this.textBoxApp = new System.Windows.Forms.TextBox();
            this.textBoxStrNum = new System.Windows.Forms.TextBox();
            this.textBoxPhone = new System.Windows.Forms.TextBox();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.textBoxPinCus = new System.Windows.Forms.TextBox();
            this.textBoxLn = new System.Windows.Forms.TextBox();
            this.textBoxFn = new System.Windows.Forms.TextBox();
            this.textBoxId = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.labelBDay = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.labelAddress = new System.Windows.Forms.Label();
            this.labelPhone = new System.Windows.Forms.Label();
            this.labelEmail = new System.Windows.Forms.Label();
            this.labelPin = new System.Windows.Forms.Label();
            this.labelLn = new System.Windows.Forms.Label();
            this.labelFn = new System.Windows.Forms.Label();
            this.labelId = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.comboBoxAccType = new System.Windows.Forms.ComboBox();
            this.textBoxAccPin = new System.Windows.Forms.TextBox();
            this.txtAccountNum = new System.Windows.Forms.TextBox();
            this.labelAccBalance = new System.Windows.Forms.Label();
            this.labelOpenDate = new System.Windows.Forms.Label();
            this.labelAccType = new System.Windows.Forms.Label();
            this.labelAccPin = new System.Windows.Forms.Label();
            this.labelAccNo = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.textBoxAccYear = new System.Windows.Forms.TextBox();
            this.textBoxAccDay = new System.Windows.Forms.TextBox();
            this.textBoxAccMonth = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.textBoxAccBalance = new System.Windows.Forms.TextBox();
            this.labelListAcc = new System.Windows.Forms.Label();
            this.listViewAccounts = new System.Windows.Forms.ListView();
            this.lstAccNumber = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstAcPin = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstAcType = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstOpenDate = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstAcBalance = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstAccTrans = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.comboBoxFromAcc = new System.Windows.Forms.ComboBox();
            this.labelFrom = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.labelTRANSACTIONS = new System.Windows.Forms.Label();
            this.textBoxTransNo = new System.Windows.Forms.TextBox();
            this.labelTransNo = new System.Windows.Forms.Label();
            this.textBoxAccNo = new System.Windows.Forms.TextBox();
            this.textBoxTransAmount = new System.Windows.Forms.TextBox();
            this.labelTransAmount = new System.Windows.Forms.Label();
            this.labelTo = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.comboBoxToAcc = new System.Windows.Forms.ComboBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.textBoxTransYear = new System.Windows.Forms.TextBox();
            this.textBoxTransDay = new System.Windows.Forms.TextBox();
            this.textBoxTransMonth = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.labelTransDate = new System.Windows.Forms.Label();
            this.textBoxTransBalance = new System.Windows.Forms.TextBox();
            this.labelTransBalance = new System.Windows.Forms.Label();
            this.comboBoxTransType = new System.Windows.Forms.ComboBox();
            this.labelTransType = new System.Windows.Forms.Label();
            this.textBoxTransDesc = new System.Windows.Forms.TextBox();
            this.labelDesc = new System.Windows.Forms.Label();
            this.labelListTrans = new System.Windows.Forms.Label();
            this.listViewTransactions = new System.Windows.Forms.ListView();
            this.columnHeaderTransNo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnTransDesc = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderTransDate = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderTransAmount = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderFromAcc = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderTransType = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.buttonReset = new System.Windows.Forms.Button();
            this.buttonSaveFile = new System.Windows.Forms.Button();
            this.buttonTransaction = new System.Windows.Forms.Button();
            this.cboCredCateg = new System.Windows.Forms.ComboBox();
            this.comboBoxCredType = new System.Windows.Forms.ComboBox();
            this.label35 = new System.Windows.Forms.Label();
            this.labelCredType = new System.Windows.Forms.Label();
            this.comboBoxSavingType = new System.Windows.Forms.ComboBox();
            this.labelSavingsType = new System.Windows.Forms.Label();
            this.comboBoxCheckingType = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxCreditCategory = new System.Windows.Forms.ComboBox();
            this.labelCredCategory = new System.Windows.Forms.Label();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonCreateAcc = new System.Windows.Forms.Button();
            this.buttonDisplayAcc = new System.Windows.Forms.Button();
            this.buttonAddThisAcc = new System.Windows.Forms.Button();
            this.buttonDisplayTrans = new System.Windows.Forms.Button();
            this.buttonConfSave = new System.Windows.Forms.Button();
            this.buttonModify = new System.Windows.Forms.Button();
            this.buttonSaveTransToFile = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBoxBYear
            // 
            this.textBoxBYear.Location = new System.Drawing.Point(210, 386);
            this.textBoxBYear.Name = "textBoxBYear";
            this.textBoxBYear.Size = new System.Drawing.Size(38, 20);
            this.textBoxBYear.TabIndex = 67;
            // 
            // textBoxBDay
            // 
            this.textBoxBDay.Location = new System.Drawing.Point(158, 386);
            this.textBoxBDay.Name = "textBoxBDay";
            this.textBoxBDay.Size = new System.Drawing.Size(31, 20);
            this.textBoxBDay.TabIndex = 66;
            // 
            // textBoxBMonth
            // 
            this.textBoxBMonth.Location = new System.Drawing.Point(103, 383);
            this.textBoxBMonth.Name = "textBoxBMonth";
            this.textBoxBMonth.Size = new System.Drawing.Size(34, 20);
            this.textBoxBMonth.TabIndex = 65;
            // 
            // textBoxStrName
            // 
            this.textBoxStrName.Location = new System.Drawing.Point(144, 272);
            this.textBoxStrName.Name = "textBoxStrName";
            this.textBoxStrName.Size = new System.Drawing.Size(104, 20);
            this.textBoxStrName.TabIndex = 64;
            // 
            // textBoxZipCode
            // 
            this.textBoxZipCode.Location = new System.Drawing.Point(144, 345);
            this.textBoxZipCode.Name = "textBoxZipCode";
            this.textBoxZipCode.Size = new System.Drawing.Size(104, 20);
            this.textBoxZipCode.TabIndex = 63;
            // 
            // textBoxCountry
            // 
            this.textBoxCountry.Location = new System.Drawing.Point(100, 345);
            this.textBoxCountry.Name = "textBoxCountry";
            this.textBoxCountry.Size = new System.Drawing.Size(38, 20);
            this.textBoxCountry.TabIndex = 62;
            // 
            // textBoxProvince
            // 
            this.textBoxProvince.Location = new System.Drawing.Point(216, 308);
            this.textBoxProvince.Name = "textBoxProvince";
            this.textBoxProvince.Size = new System.Drawing.Size(32, 20);
            this.textBoxProvince.TabIndex = 61;
            // 
            // textBoxCity
            // 
            this.textBoxCity.Location = new System.Drawing.Point(144, 308);
            this.textBoxCity.Name = "textBoxCity";
            this.textBoxCity.Size = new System.Drawing.Size(66, 20);
            this.textBoxCity.TabIndex = 60;
            // 
            // textBoxApp
            // 
            this.textBoxApp.Location = new System.Drawing.Point(100, 308);
            this.textBoxApp.Name = "textBoxApp";
            this.textBoxApp.Size = new System.Drawing.Size(38, 20);
            this.textBoxApp.TabIndex = 59;
            this.textBoxApp.TextChanged += new System.EventHandler(this.textBoxApp_TextChanged);
            // 
            // textBoxStrNum
            // 
            this.textBoxStrNum.Location = new System.Drawing.Point(100, 272);
            this.textBoxStrNum.Name = "textBoxStrNum";
            this.textBoxStrNum.Size = new System.Drawing.Size(37, 20);
            this.textBoxStrNum.TabIndex = 58;
            // 
            // textBoxPhone
            // 
            this.textBoxPhone.Location = new System.Drawing.Point(148, 246);
            this.textBoxPhone.Name = "textBoxPhone";
            this.textBoxPhone.Size = new System.Drawing.Size(100, 20);
            this.textBoxPhone.TabIndex = 57;
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Location = new System.Drawing.Point(148, 220);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(100, 20);
            this.textBoxEmail.TabIndex = 56;
            // 
            // textBoxPinCus
            // 
            this.textBoxPinCus.Location = new System.Drawing.Point(148, 194);
            this.textBoxPinCus.Name = "textBoxPinCus";
            this.textBoxPinCus.Size = new System.Drawing.Size(100, 20);
            this.textBoxPinCus.TabIndex = 55;
            // 
            // textBoxLn
            // 
            this.textBoxLn.Location = new System.Drawing.Point(148, 168);
            this.textBoxLn.Name = "textBoxLn";
            this.textBoxLn.Size = new System.Drawing.Size(100, 20);
            this.textBoxLn.TabIndex = 54;
            // 
            // textBoxFn
            // 
            this.textBoxFn.Location = new System.Drawing.Point(148, 142);
            this.textBoxFn.Name = "textBoxFn";
            this.textBoxFn.Size = new System.Drawing.Size(100, 20);
            this.textBoxFn.TabIndex = 1;
            this.textBoxFn.TextChanged += new System.EventHandler(this.textBoxFn_TextChanged);
            this.textBoxFn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxFn_KeyPress);
            // 
            // textBoxId
            // 
            this.textBoxId.Location = new System.Drawing.Point(148, 116);
            this.textBoxId.Name = "textBoxId";
            this.textBoxId.Size = new System.Drawing.Size(100, 20);
            this.textBoxId.TabIndex = 52;
            this.textBoxId.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxId_KeyPress);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(216, 409);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(24, 10);
            this.label18.TabIndex = 51;
            this.label18.Text = "YEAR";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(106, 409);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(31, 10);
            this.label17.TabIndex = 50;
            this.label17.Text = "MONTH";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(162, 409);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(19, 10);
            this.label16.TabIndex = 49;
            this.label16.Text = "DAY";
            // 
            // labelBDay
            // 
            this.labelBDay.AutoSize = true;
            this.labelBDay.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBDay.Location = new System.Drawing.Point(32, 389);
            this.labelBDay.Name = "labelBDay";
            this.labelBDay.Size = new System.Drawing.Size(55, 13);
            this.labelBDay.TabIndex = 48;
            this.labelBDay.Text = "BIRTHDAY";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(163, 368);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 10);
            this.label14.TabIndex = 47;
            this.label14.Text = "POSTAL CODE";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(103, 368);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(39, 10);
            this.label13.TabIndex = 46;
            this.label13.Text = "COUNTRY";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(221, 331);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(27, 10);
            this.label12.TabIndex = 45;
            this.label12.Text = "PROV.";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(164, 331);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(20, 10);
            this.label11.TabIndex = 44;
            this.label11.Text = "CITY";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(101, 331);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 10);
            this.label10.TabIndex = 43;
            this.label10.Text = "APTO No.";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(162, 295);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 10);
            this.label9.TabIndex = 42;
            this.label9.Text = "STREET NAME";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(101, 295);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 10);
            this.label8.TabIndex = 41;
            this.label8.Text = "STREET No.";
            // 
            // labelAddress
            // 
            this.labelAddress.AutoSize = true;
            this.labelAddress.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAddress.Location = new System.Drawing.Point(32, 278);
            this.labelAddress.Name = "labelAddress";
            this.labelAddress.Size = new System.Drawing.Size(56, 13);
            this.labelAddress.TabIndex = 40;
            this.labelAddress.Text = "ADDRESS";
            // 
            // labelPhone
            // 
            this.labelPhone.AutoSize = true;
            this.labelPhone.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPhone.Location = new System.Drawing.Point(32, 253);
            this.labelPhone.Name = "labelPhone";
            this.labelPhone.Size = new System.Drawing.Size(90, 13);
            this.labelPhone.TabIndex = 39;
            this.labelPhone.Text = "PHONE NUMBER";
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEmail.Location = new System.Drawing.Point(32, 227);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(39, 13);
            this.labelEmail.TabIndex = 38;
            this.labelEmail.Text = "EMAIL";
            // 
            // labelPin
            // 
            this.labelPin.AutoSize = true;
            this.labelPin.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPin.Location = new System.Drawing.Point(32, 201);
            this.labelPin.Name = "labelPin";
            this.labelPin.Size = new System.Drawing.Size(25, 13);
            this.labelPin.TabIndex = 37;
            this.labelPin.Text = "PIN";
            // 
            // labelLn
            // 
            this.labelLn.AutoSize = true;
            this.labelLn.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLn.Location = new System.Drawing.Point(32, 175);
            this.labelLn.Name = "labelLn";
            this.labelLn.Size = new System.Drawing.Size(65, 13);
            this.labelLn.TabIndex = 36;
            this.labelLn.Text = "LAST NAME";
            // 
            // labelFn
            // 
            this.labelFn.AutoSize = true;
            this.labelFn.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFn.Location = new System.Drawing.Point(32, 149);
            this.labelFn.Name = "labelFn";
            this.labelFn.Size = new System.Drawing.Size(68, 13);
            this.labelFn.TabIndex = 35;
            this.labelFn.Text = "FIRST NAME";
            // 
            // labelId
            // 
            this.labelId.AutoSize = true;
            this.labelId.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelId.Location = new System.Drawing.Point(32, 123);
            this.labelId.Name = "labelId";
            this.labelId.Size = new System.Drawing.Size(17, 13);
            this.labelId.TabIndex = 34;
            this.labelId.Text = "ID";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label19.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(141, 389);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(13, 15);
            this.label19.TabIndex = 68;
            this.label19.Text = "/";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label20.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(193, 389);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(13, 15);
            this.label20.TabIndex = 69;
            this.label20.Text = "/";
            // 
            // comboBoxAccType
            // 
            this.comboBoxAccType.FormattingEnabled = true;
            this.comboBoxAccType.Location = new System.Drawing.Point(725, 182);
            this.comboBoxAccType.Name = "comboBoxAccType";
            this.comboBoxAccType.Size = new System.Drawing.Size(121, 21);
            this.comboBoxAccType.TabIndex = 78;
            // 
            // textBoxAccPin
            // 
            this.textBoxAccPin.Location = new System.Drawing.Point(725, 122);
            this.textBoxAccPin.Name = "textBoxAccPin";
            this.textBoxAccPin.Size = new System.Drawing.Size(121, 20);
            this.textBoxAccPin.TabIndex = 77;
            this.textBoxAccPin.TextChanged += new System.EventHandler(this.textBoxAccPin_TextChanged);
            // 
            // txtAccountNum
            // 
            this.txtAccountNum.Location = new System.Drawing.Point(710, -46);
            this.txtAccountNum.Name = "txtAccountNum";
            this.txtAccountNum.Size = new System.Drawing.Size(121, 20);
            this.txtAccountNum.TabIndex = 76;
            // 
            // labelAccBalance
            // 
            this.labelAccBalance.AutoSize = true;
            this.labelAccBalance.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAccBalance.Location = new System.Drawing.Point(610, 323);
            this.labelAccBalance.Name = "labelAccBalance";
            this.labelAccBalance.Size = new System.Drawing.Size(56, 13);
            this.labelAccBalance.TabIndex = 74;
            this.labelAccBalance.Text = "BALANCE";
            // 
            // labelOpenDate
            // 
            this.labelOpenDate.AutoSize = true;
            this.labelOpenDate.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOpenDate.Location = new System.Drawing.Point(610, 153);
            this.labelOpenDate.Name = "labelOpenDate";
            this.labelOpenDate.Size = new System.Drawing.Size(64, 13);
            this.labelOpenDate.TabIndex = 73;
            this.labelOpenDate.Text = "OPEN DATE";
            // 
            // labelAccType
            // 
            this.labelAccType.AutoSize = true;
            this.labelAccType.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAccType.Location = new System.Drawing.Point(610, 185);
            this.labelAccType.Name = "labelAccType";
            this.labelAccType.Size = new System.Drawing.Size(57, 13);
            this.labelAccType.TabIndex = 72;
            this.labelAccType.Text = "ACC. TYPE";
            // 
            // labelAccPin
            // 
            this.labelAccPin.AutoSize = true;
            this.labelAccPin.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAccPin.Location = new System.Drawing.Point(610, 125);
            this.labelAccPin.Name = "labelAccPin";
            this.labelAccPin.Size = new System.Drawing.Size(50, 13);
            this.labelAccPin.TabIndex = 71;
            this.labelAccPin.Text = "ACC. PIN";
            // 
            // labelAccNo
            // 
            this.labelAccNo.AutoSize = true;
            this.labelAccNo.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAccNo.Location = new System.Drawing.Point(610, 100);
            this.labelAccNo.Name = "labelAccNo";
            this.labelAccNo.Size = new System.Drawing.Size(77, 13);
            this.labelAccNo.TabIndex = 70;
            this.labelAccNo.Text = "ACC. NUMBER";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label25.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(791, 151);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(13, 15);
            this.label25.TabIndex = 86;
            this.label25.Text = "/";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label28.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(739, 151);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(13, 15);
            this.label28.TabIndex = 85;
            this.label28.Text = "/";
            // 
            // textBoxAccYear
            // 
            this.textBoxAccYear.Location = new System.Drawing.Point(808, 148);
            this.textBoxAccYear.Name = "textBoxAccYear";
            this.textBoxAccYear.Size = new System.Drawing.Size(38, 20);
            this.textBoxAccYear.TabIndex = 84;
            this.textBoxAccYear.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxAccYear_KeyPress);
            // 
            // textBoxAccDay
            // 
            this.textBoxAccDay.Location = new System.Drawing.Point(756, 148);
            this.textBoxAccDay.Name = "textBoxAccDay";
            this.textBoxAccDay.Size = new System.Drawing.Size(31, 20);
            this.textBoxAccDay.TabIndex = 83;
            this.textBoxAccDay.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxAccDay_KeyPress);
            // 
            // textBoxAccMonth
            // 
            this.textBoxAccMonth.Location = new System.Drawing.Point(701, 148);
            this.textBoxAccMonth.Name = "textBoxAccMonth";
            this.textBoxAccMonth.Size = new System.Drawing.Size(34, 20);
            this.textBoxAccMonth.TabIndex = 82;
            this.textBoxAccMonth.TextChanged += new System.EventHandler(this.textBoxAccMonth_TextChanged);
            this.textBoxAccMonth.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxAccMonth_KeyPress);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(814, 171);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(24, 10);
            this.label29.TabIndex = 81;
            this.label29.Text = "YEAR";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(704, 171);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(31, 10);
            this.label30.TabIndex = 80;
            this.label30.Text = "MONTH";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(760, 171);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(19, 10);
            this.label31.TabIndex = 79;
            this.label31.Text = "DAY";
            // 
            // textBoxAccBalance
            // 
            this.textBoxAccBalance.Location = new System.Drawing.Point(725, 320);
            this.textBoxAccBalance.Name = "textBoxAccBalance";
            this.textBoxAccBalance.Size = new System.Drawing.Size(121, 20);
            this.textBoxAccBalance.TabIndex = 87;
            // 
            // labelListAcc
            // 
            this.labelListAcc.AutoSize = true;
            this.labelListAcc.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelListAcc.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelListAcc.Location = new System.Drawing.Point(678, 347);
            this.labelListAcc.Name = "labelListAcc";
            this.labelListAcc.Size = new System.Drawing.Size(109, 15);
            this.labelListAcc.TabIndex = 90;
            this.labelListAcc.Text = "LIST OF ACCCOUNTS";
            // 
            // listViewAccounts
            // 
            this.listViewAccounts.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lstAccNumber,
            this.lstAcPin,
            this.lstAcType,
            this.lstOpenDate,
            this.lstAcBalance,
            this.lstAccTrans});
            listViewGroup1.Header = "ListViewGroup";
            listViewGroup1.Name = "listViewGroup2";
            this.listViewAccounts.Groups.AddRange(new System.Windows.Forms.ListViewGroup[] {
            listViewGroup1});
            this.listViewAccounts.Location = new System.Drawing.Point(612, 367);
            this.listViewAccounts.Name = "listViewAccounts";
            this.listViewAccounts.Size = new System.Drawing.Size(234, 69);
            this.listViewAccounts.TabIndex = 89;
            this.listViewAccounts.UseCompatibleStateImageBehavior = false;
            this.listViewAccounts.View = System.Windows.Forms.View.Details;
            this.listViewAccounts.SelectedIndexChanged += new System.EventHandler(this.listViewAccounts_SelectedIndexChanged);
            // 
            // lstAccNumber
            // 
            this.lstAccNumber.Text = "Number";
            // 
            // lstAcPin
            // 
            this.lstAcPin.Text = "PIN";
            this.lstAcPin.Width = 48;
            // 
            // lstAcType
            // 
            this.lstAcType.Text = "Type";
            this.lstAcType.Width = 63;
            // 
            // lstOpenDate
            // 
            this.lstOpenDate.Text = "Open Day";
            // 
            // lstAcBalance
            // 
            this.lstAcBalance.Text = "Balance";
            // 
            // lstAccTrans
            // 
            this.lstAccTrans.Text = "Transaction";
            // 
            // comboBoxFromAcc
            // 
            this.comboBoxFromAcc.FormattingEnabled = true;
            this.comboBoxFromAcc.Location = new System.Drawing.Point(422, 148);
            this.comboBoxFromAcc.Name = "comboBoxFromAcc";
            this.comboBoxFromAcc.Size = new System.Drawing.Size(122, 21);
            this.comboBoxFromAcc.TabIndex = 93;
            this.comboBoxFromAcc.SelectedIndexChanged += new System.EventHandler(this.comboBoxFromAcc_SelectedIndexChanged);
            // 
            // labelFrom
            // 
            this.labelFrom.AutoSize = true;
            this.labelFrom.BackColor = System.Drawing.Color.LightSeaGreen;
            this.labelFrom.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFrom.Location = new System.Drawing.Point(348, 154);
            this.labelFrom.Name = "labelFrom";
            this.labelFrom.Size = new System.Drawing.Size(36, 13);
            this.labelFrom.TabIndex = 92;
            this.labelFrom.Text = "FROM";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.Color.LightSeaGreen;
            this.label34.Font = new System.Drawing.Font("Bahnschrift", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(422, 171);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(79, 13);
            this.label34.TabIndex = 94;
            this.label34.Text = "Select Account";
            // 
            // labelTRANSACTIONS
            // 
            this.labelTRANSACTIONS.AutoSize = true;
            this.labelTRANSACTIONS.BackColor = System.Drawing.Color.LightSeaGreen;
            this.labelTRANSACTIONS.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTRANSACTIONS.Location = new System.Drawing.Point(375, 78);
            this.labelTRANSACTIONS.Name = "labelTRANSACTIONS";
            this.labelTRANSACTIONS.Size = new System.Drawing.Size(85, 13);
            this.labelTRANSACTIONS.TabIndex = 95;
            this.labelTRANSACTIONS.Text = "TRANSACTIONS";
            // 
            // textBoxTransNo
            // 
            this.textBoxTransNo.Location = new System.Drawing.Point(423, 97);
            this.textBoxTransNo.Name = "textBoxTransNo";
            this.textBoxTransNo.Size = new System.Drawing.Size(121, 20);
            this.textBoxTransNo.TabIndex = 97;
            // 
            // labelTransNo
            // 
            this.labelTransNo.AutoSize = true;
            this.labelTransNo.BackColor = System.Drawing.Color.LightSeaGreen;
            this.labelTransNo.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTransNo.Location = new System.Drawing.Point(321, 101);
            this.labelTransNo.Name = "labelTransNo";
            this.labelTransNo.Size = new System.Drawing.Size(61, 13);
            this.labelTransNo.TabIndex = 96;
            this.labelTransNo.Text = "TRANS. No.";
            // 
            // textBoxAccNo
            // 
            this.textBoxAccNo.Location = new System.Drawing.Point(725, 95);
            this.textBoxAccNo.Name = "textBoxAccNo";
            this.textBoxAccNo.Size = new System.Drawing.Size(121, 20);
            this.textBoxAccNo.TabIndex = 98;
            this.textBoxAccNo.TextChanged += new System.EventHandler(this.textBoxAccNo_TextChanged);
            this.textBoxAccNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxAccNo_KeyPress);
            // 
            // textBoxTransAmount
            // 
            this.textBoxTransAmount.Location = new System.Drawing.Point(423, 187);
            this.textBoxTransAmount.Name = "textBoxTransAmount";
            this.textBoxTransAmount.Size = new System.Drawing.Size(121, 20);
            this.textBoxTransAmount.TabIndex = 100;
            // 
            // labelTransAmount
            // 
            this.labelTransAmount.AutoSize = true;
            this.labelTransAmount.BackColor = System.Drawing.Color.LightSeaGreen;
            this.labelTransAmount.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTransAmount.Location = new System.Drawing.Point(332, 190);
            this.labelTransAmount.Name = "labelTransAmount";
            this.labelTransAmount.Size = new System.Drawing.Size(50, 13);
            this.labelTransAmount.TabIndex = 99;
            this.labelTransAmount.Text = "AMOUNT";
            // 
            // labelTo
            // 
            this.labelTo.AutoSize = true;
            this.labelTo.BackColor = System.Drawing.Color.LightSeaGreen;
            this.labelTo.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTo.Location = new System.Drawing.Point(362, 215);
            this.labelTo.Name = "labelTo";
            this.labelTo.Size = new System.Drawing.Size(19, 13);
            this.labelTo.TabIndex = 101;
            this.labelTo.Text = "TO";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.Color.LightSeaGreen;
            this.label39.Font = new System.Drawing.Font("Bahnschrift", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(422, 234);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(79, 13);
            this.label39.TabIndex = 103;
            this.label39.Text = "Select Account";
            // 
            // comboBoxToAcc
            // 
            this.comboBoxToAcc.FormattingEnabled = true;
            this.comboBoxToAcc.Location = new System.Drawing.Point(423, 212);
            this.comboBoxToAcc.Name = "comboBoxToAcc";
            this.comboBoxToAcc.Size = new System.Drawing.Size(121, 21);
            this.comboBoxToAcc.TabIndex = 102;
            this.comboBoxToAcc.SelectedIndexChanged += new System.EventHandler(this.comboBoxToAcc_SelectedIndexChanged);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.Color.LightSeaGreen;
            this.label40.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(488, 252);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(11, 13);
            this.label40.TabIndex = 112;
            this.label40.Text = "/";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.Color.LightSeaGreen;
            this.label41.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(436, 252);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(11, 13);
            this.label41.TabIndex = 111;
            this.label41.Text = "/";
            // 
            // textBoxTransYear
            // 
            this.textBoxTransYear.Location = new System.Drawing.Point(505, 249);
            this.textBoxTransYear.Name = "textBoxTransYear";
            this.textBoxTransYear.Size = new System.Drawing.Size(38, 20);
            this.textBoxTransYear.TabIndex = 110;
            this.textBoxTransYear.TextChanged += new System.EventHandler(this.textBoxTransYear_TextChanged);
            // 
            // textBoxTransDay
            // 
            this.textBoxTransDay.Location = new System.Drawing.Point(453, 249);
            this.textBoxTransDay.Name = "textBoxTransDay";
            this.textBoxTransDay.Size = new System.Drawing.Size(31, 20);
            this.textBoxTransDay.TabIndex = 109;
            // 
            // textBoxTransMonth
            // 
            this.textBoxTransMonth.Location = new System.Drawing.Point(398, 249);
            this.textBoxTransMonth.Name = "textBoxTransMonth";
            this.textBoxTransMonth.Size = new System.Drawing.Size(34, 20);
            this.textBoxTransMonth.TabIndex = 108;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.LightSeaGreen;
            this.label42.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(511, 272);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(24, 10);
            this.label42.TabIndex = 107;
            this.label42.Text = "YEAR";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.LightSeaGreen;
            this.label43.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(401, 272);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(31, 10);
            this.label43.TabIndex = 106;
            this.label43.Text = "MONTH";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.LightSeaGreen;
            this.label44.Font = new System.Drawing.Font("Bahnschrift", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(457, 272);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(19, 10);
            this.label44.TabIndex = 105;
            this.label44.Text = "DAY";
            // 
            // labelTransDate
            // 
            this.labelTransDate.AutoSize = true;
            this.labelTransDate.BackColor = System.Drawing.Color.LightSeaGreen;
            this.labelTransDate.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTransDate.Location = new System.Drawing.Point(311, 252);
            this.labelTransDate.Name = "labelTransDate";
            this.labelTransDate.Size = new System.Drawing.Size(71, 13);
            this.labelTransDate.TabIndex = 104;
            this.labelTransDate.Text = "TRANS. DATE";
            // 
            // textBoxTransBalance
            // 
            this.textBoxTransBalance.Location = new System.Drawing.Point(422, 311);
            this.textBoxTransBalance.Name = "textBoxTransBalance";
            this.textBoxTransBalance.Size = new System.Drawing.Size(121, 20);
            this.textBoxTransBalance.TabIndex = 114;
            // 
            // labelTransBalance
            // 
            this.labelTransBalance.AutoSize = true;
            this.labelTransBalance.BackColor = System.Drawing.Color.LightSeaGreen;
            this.labelTransBalance.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTransBalance.Location = new System.Drawing.Point(325, 314);
            this.labelTransBalance.Name = "labelTransBalance";
            this.labelTransBalance.Size = new System.Drawing.Size(56, 13);
            this.labelTransBalance.TabIndex = 113;
            this.labelTransBalance.Text = "BALANCE";
            // 
            // comboBoxTransType
            // 
            this.comboBoxTransType.FormattingEnabled = true;
            this.comboBoxTransType.Location = new System.Drawing.Point(423, 122);
            this.comboBoxTransType.Name = "comboBoxTransType";
            this.comboBoxTransType.Size = new System.Drawing.Size(121, 21);
            this.comboBoxTransType.TabIndex = 116;
            // 
            // labelTransType
            // 
            this.labelTransType.AutoSize = true;
            this.labelTransType.BackColor = System.Drawing.Color.LightSeaGreen;
            this.labelTransType.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTransType.Location = new System.Drawing.Point(311, 128);
            this.labelTransType.Name = "labelTransType";
            this.labelTransType.Size = new System.Drawing.Size(70, 13);
            this.labelTransType.TabIndex = 115;
            this.labelTransType.Text = "TRANS. TYPE";
            // 
            // textBoxTransDesc
            // 
            this.textBoxTransDesc.Location = new System.Drawing.Point(422, 286);
            this.textBoxTransDesc.Name = "textBoxTransDesc";
            this.textBoxTransDesc.Size = new System.Drawing.Size(121, 20);
            this.textBoxTransDesc.TabIndex = 118;
            // 
            // labelDesc
            // 
            this.labelDesc.AutoSize = true;
            this.labelDesc.BackColor = System.Drawing.Color.LightSeaGreen;
            this.labelDesc.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDesc.Location = new System.Drawing.Point(307, 289);
            this.labelDesc.Name = "labelDesc";
            this.labelDesc.Size = new System.Drawing.Size(75, 13);
            this.labelDesc.TabIndex = 117;
            this.labelDesc.Text = "DESCRIPTION";
            // 
            // labelListTrans
            // 
            this.labelListTrans.AutoSize = true;
            this.labelListTrans.BackColor = System.Drawing.Color.LightSeaGreen;
            this.labelListTrans.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelListTrans.Location = new System.Drawing.Point(370, 340);
            this.labelListTrans.Name = "labelListTrans";
            this.labelListTrans.Size = new System.Drawing.Size(123, 13);
            this.labelListTrans.TabIndex = 120;
            this.labelListTrans.Text = "LIST OF TRANSACTIONS";
            // 
            // listViewTransactions
            // 
            this.listViewTransactions.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderTransNo,
            this.columnTransDesc,
            this.columnHeaderTransDate,
            this.columnHeaderTransAmount,
            this.columnHeaderFromAcc,
            this.columnHeaderTransType});
            listViewGroup2.Header = "ListViewGroup";
            listViewGroup2.Name = "listViewGroup2";
            this.listViewTransactions.Groups.AddRange(new System.Windows.Forms.ListViewGroup[] {
            listViewGroup2});
            this.listViewTransactions.Location = new System.Drawing.Point(305, 356);
            this.listViewTransactions.Name = "listViewTransactions";
            this.listViewTransactions.Size = new System.Drawing.Size(243, 92);
            this.listViewTransactions.TabIndex = 119;
            this.listViewTransactions.UseCompatibleStateImageBehavior = false;
            this.listViewTransactions.View = System.Windows.Forms.View.Details;
            this.listViewTransactions.SelectedIndexChanged += new System.EventHandler(this.listViewTransactions_SelectedIndexChanged);
            // 
            // columnHeaderTransNo
            // 
            this.columnHeaderTransNo.Text = "Trans.No.";
            // 
            // columnTransDesc
            // 
            this.columnTransDesc.Text = "Desc.";
            this.columnTransDesc.Width = 59;
            // 
            // columnHeaderTransDate
            // 
            this.columnHeaderTransDate.Text = "Date";
            // 
            // columnHeaderTransAmount
            // 
            this.columnHeaderTransAmount.Text = "Amount";
            // 
            // columnHeaderFromAcc
            // 
            this.columnHeaderFromAcc.Text = "Account";
            // 
            // columnHeaderTransType
            // 
            this.columnHeaderTransType.Text = "Type";
            // 
            // buttonReset
            // 
            this.buttonReset.BackgroundImage = global::Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.Properties.Resources.botton_2;
            this.buttonReset.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonReset.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonReset.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonReset.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.buttonReset.Location = new System.Drawing.Point(418, 22);
            this.buttonReset.Name = "buttonReset";
            this.buttonReset.Size = new System.Drawing.Size(98, 34);
            this.buttonReset.TabIndex = 127;
            this.buttonReset.Text = "Reset";
            this.buttonReset.UseVisualStyleBackColor = true;
            this.buttonReset.Click += new System.EventHandler(this.buttonReset_Click);
            // 
            // buttonSaveFile
            // 
            this.buttonSaveFile.BackgroundImage = global::Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.Properties.Resources.botton_2;
            this.buttonSaveFile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonSaveFile.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonSaveFile.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSaveFile.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.buttonSaveFile.Location = new System.Drawing.Point(637, 22);
            this.buttonSaveFile.Name = "buttonSaveFile";
            this.buttonSaveFile.Size = new System.Drawing.Size(98, 34);
            this.buttonSaveFile.TabIndex = 126;
            this.buttonSaveFile.Text = "Save Acc. To Database";
            this.buttonSaveFile.UseVisualStyleBackColor = true;
            this.buttonSaveFile.Click += new System.EventHandler(this.buttonSaveFile_Click);
            // 
            // buttonTransaction
            // 
            this.buttonTransaction.BackgroundImage = global::Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.Properties.Resources.botton_2;
            this.buttonTransaction.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonTransaction.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonTransaction.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTransaction.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.buttonTransaction.Location = new System.Drawing.Point(307, 22);
            this.buttonTransaction.Name = "buttonTransaction";
            this.buttonTransaction.Size = new System.Drawing.Size(98, 34);
            this.buttonTransaction.TabIndex = 128;
            this.buttonTransaction.Text = "Transaction";
            this.buttonTransaction.UseVisualStyleBackColor = true;
            this.buttonTransaction.Click += new System.EventHandler(this.buttonTransaction_Click);
            // 
            // cboCredCateg
            // 
            this.cboCredCateg.FormattingEnabled = true;
            this.cboCredCateg.Location = new System.Drawing.Point(612, 551);
            this.cboCredCateg.Name = "cboCredCateg";
            this.cboCredCateg.Size = new System.Drawing.Size(121, 21);
            this.cboCredCateg.TabIndex = 137;
            // 
            // comboBoxCredType
            // 
            this.comboBoxCredType.FormattingEnabled = true;
            this.comboBoxCredType.Location = new System.Drawing.Point(725, 266);
            this.comboBoxCredType.Name = "comboBoxCredType";
            this.comboBoxCredType.Size = new System.Drawing.Size(121, 21);
            this.comboBoxCredType.TabIndex = 136;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(483, 554);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(109, 13);
            this.label35.TabIndex = 135;
            this.label35.Text = "CREDIT CATEGORY";
            // 
            // labelCredType
            // 
            this.labelCredType.AutoSize = true;
            this.labelCredType.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCredType.Location = new System.Drawing.Point(610, 269);
            this.labelCredType.Name = "labelCredType";
            this.labelCredType.Size = new System.Drawing.Size(70, 13);
            this.labelCredType.TabIndex = 134;
            this.labelCredType.Text = "CREDIT TYPE";
            // 
            // comboBoxSavingType
            // 
            this.comboBoxSavingType.FormattingEnabled = true;
            this.comboBoxSavingType.Location = new System.Drawing.Point(725, 238);
            this.comboBoxSavingType.Name = "comboBoxSavingType";
            this.comboBoxSavingType.Size = new System.Drawing.Size(121, 21);
            this.comboBoxSavingType.TabIndex = 133;
            // 
            // labelSavingsType
            // 
            this.labelSavingsType.AutoSize = true;
            this.labelSavingsType.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSavingsType.Location = new System.Drawing.Point(610, 241);
            this.labelSavingsType.Name = "labelSavingsType";
            this.labelSavingsType.Size = new System.Drawing.Size(71, 13);
            this.labelSavingsType.TabIndex = 132;
            this.labelSavingsType.Text = "SAVING TYPE";
            // 
            // comboBoxCheckingType
            // 
            this.comboBoxCheckingType.FormattingEnabled = true;
            this.comboBoxCheckingType.Location = new System.Drawing.Point(725, 210);
            this.comboBoxCheckingType.Name = "comboBoxCheckingType";
            this.comboBoxCheckingType.Size = new System.Drawing.Size(121, 21);
            this.comboBoxCheckingType.TabIndex = 131;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(610, 213);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 13);
            this.label2.TabIndex = 130;
            this.label2.Text = "CHECKING TYPE";
            // 
            // comboBoxCreditCategory
            // 
            this.comboBoxCreditCategory.FormattingEnabled = true;
            this.comboBoxCreditCategory.Location = new System.Drawing.Point(725, 293);
            this.comboBoxCreditCategory.Name = "comboBoxCreditCategory";
            this.comboBoxCreditCategory.Size = new System.Drawing.Size(121, 21);
            this.comboBoxCreditCategory.TabIndex = 139;
            // 
            // labelCredCategory
            // 
            this.labelCredCategory.AutoSize = true;
            this.labelCredCategory.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCredCategory.Location = new System.Drawing.Point(610, 296);
            this.labelCredCategory.Name = "labelCredCategory";
            this.labelCredCategory.Size = new System.Drawing.Size(98, 13);
            this.labelCredCategory.TabIndex = 138;
            this.labelCredCategory.Text = "CREDIT CATEGORY";
            // 
            // buttonExit
            // 
            this.buttonExit.BackgroundImage = global::Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.Properties.Resources.button_3;
            this.buttonExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonExit.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExit.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.buttonExit.Location = new System.Drawing.Point(748, 22);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(98, 34);
            this.buttonExit.TabIndex = 126;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonCreateAcc
            // 
            this.buttonCreateAcc.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonCreateAcc.BackgroundImage")));
            this.buttonCreateAcc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonCreateAcc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonCreateAcc.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCreateAcc.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.buttonCreateAcc.Location = new System.Drawing.Point(197, 22);
            this.buttonCreateAcc.Name = "buttonCreateAcc";
            this.buttonCreateAcc.Size = new System.Drawing.Size(98, 34);
            this.buttonCreateAcc.TabIndex = 129;
            this.buttonCreateAcc.Text = "Create Account";
            this.buttonCreateAcc.UseVisualStyleBackColor = true;
            this.buttonCreateAcc.Click += new System.EventHandler(this.buttonCreateAcc_Click);
            // 
            // buttonDisplayAcc
            // 
            this.buttonDisplayAcc.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonDisplayAcc.BackgroundImage")));
            this.buttonDisplayAcc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonDisplayAcc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDisplayAcc.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDisplayAcc.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.buttonDisplayAcc.Location = new System.Drawing.Point(739, 474);
            this.buttonDisplayAcc.Name = "buttonDisplayAcc";
            this.buttonDisplayAcc.Size = new System.Drawing.Size(98, 34);
            this.buttonDisplayAcc.TabIndex = 124;
            this.buttonDisplayAcc.Text = "Display Accounts";
            this.buttonDisplayAcc.UseVisualStyleBackColor = true;
            this.buttonDisplayAcc.Click += new System.EventHandler(this.buttonDisplayAcc_Click);
            // 
            // buttonAddThisAcc
            // 
            this.buttonAddThisAcc.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonAddThisAcc.BackgroundImage")));
            this.buttonAddThisAcc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonAddThisAcc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonAddThisAcc.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddThisAcc.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.buttonAddThisAcc.Location = new System.Drawing.Point(627, 474);
            this.buttonAddThisAcc.Name = "buttonAddThisAcc";
            this.buttonAddThisAcc.Size = new System.Drawing.Size(98, 34);
            this.buttonAddThisAcc.TabIndex = 124;
            this.buttonAddThisAcc.Text = "Create This Account";
            this.buttonAddThisAcc.UseVisualStyleBackColor = true;
            this.buttonAddThisAcc.Click += new System.EventHandler(this.buttonAddThisAcc_Click);
            // 
            // buttonDisplayTrans
            // 
            this.buttonDisplayTrans.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonDisplayTrans.BackgroundImage")));
            this.buttonDisplayTrans.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonDisplayTrans.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonDisplayTrans.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDisplayTrans.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.buttonDisplayTrans.Location = new System.Drawing.Point(435, 474);
            this.buttonDisplayTrans.Name = "buttonDisplayTrans";
            this.buttonDisplayTrans.Size = new System.Drawing.Size(98, 34);
            this.buttonDisplayTrans.TabIndex = 123;
            this.buttonDisplayTrans.Text = "Display Transactions";
            this.buttonDisplayTrans.UseVisualStyleBackColor = true;
            this.buttonDisplayTrans.Click += new System.EventHandler(this.buttonDisplayTrans_Click);
            // 
            // buttonConfSave
            // 
            this.buttonConfSave.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonConfSave.BackgroundImage")));
            this.buttonConfSave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonConfSave.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonConfSave.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonConfSave.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.buttonConfSave.Location = new System.Drawing.Point(322, 474);
            this.buttonConfSave.Name = "buttonConfSave";
            this.buttonConfSave.Size = new System.Drawing.Size(98, 34);
            this.buttonConfSave.TabIndex = 123;
            this.buttonConfSave.Text = "Confirm Transaction";
            this.buttonConfSave.UseVisualStyleBackColor = true;
            this.buttonConfSave.Click += new System.EventHandler(this.buttonConfSave_Click);
            // 
            // buttonModify
            // 
            this.buttonModify.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonModify.BackgroundImage")));
            this.buttonModify.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonModify.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonModify.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonModify.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.buttonModify.Location = new System.Drawing.Point(83, 474);
            this.buttonModify.Name = "buttonModify";
            this.buttonModify.Size = new System.Drawing.Size(98, 34);
            this.buttonModify.TabIndex = 121;
            this.buttonModify.Text = "Modify Profil";
            this.buttonModify.UseVisualStyleBackColor = true;
            this.buttonModify.Click += new System.EventHandler(this.buttonModify_Click);
            // 
            // buttonSaveTransToFile
            // 
            this.buttonSaveTransToFile.BackgroundImage = global::Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.Properties.Resources.botton_2;
            this.buttonSaveTransToFile.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonSaveTransToFile.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSaveTransToFile.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonSaveTransToFile.Location = new System.Drawing.Point(529, 22);
            this.buttonSaveTransToFile.Name = "buttonSaveTransToFile";
            this.buttonSaveTransToFile.Size = new System.Drawing.Size(97, 34);
            this.buttonSaveTransToFile.TabIndex = 140;
            this.buttonSaveTransToFile.Text = "Save Trans. To Database";
            this.buttonSaveTransToFile.UseVisualStyleBackColor = true;
            this.buttonSaveTransToFile.Click += new System.EventHandler(this.buttonSaveTransToFile_Click);
            // 
            // CustomerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.Properties.Resources._5_FINAL;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(877, 538);
            this.Controls.Add(this.buttonSaveTransToFile);
            this.Controls.Add(this.comboBoxCreditCategory);
            this.Controls.Add(this.labelCredCategory);
            this.Controls.Add(this.cboCredCateg);
            this.Controls.Add(this.comboBoxCredType);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.labelCredType);
            this.Controls.Add(this.comboBoxSavingType);
            this.Controls.Add(this.labelSavingsType);
            this.Controls.Add(this.comboBoxCheckingType);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.buttonCreateAcc);
            this.Controls.Add(this.buttonTransaction);
            this.Controls.Add(this.buttonReset);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonSaveFile);
            this.Controls.Add(this.buttonDisplayAcc);
            this.Controls.Add(this.buttonAddThisAcc);
            this.Controls.Add(this.buttonDisplayTrans);
            this.Controls.Add(this.buttonConfSave);
            this.Controls.Add(this.buttonModify);
            this.Controls.Add(this.labelListTrans);
            this.Controls.Add(this.listViewTransactions);
            this.Controls.Add(this.textBoxTransDesc);
            this.Controls.Add(this.labelDesc);
            this.Controls.Add(this.comboBoxTransType);
            this.Controls.Add(this.labelTransType);
            this.Controls.Add(this.textBoxTransBalance);
            this.Controls.Add(this.labelTransBalance);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.textBoxTransYear);
            this.Controls.Add(this.textBoxTransDay);
            this.Controls.Add(this.textBoxTransMonth);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.labelTransDate);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.comboBoxToAcc);
            this.Controls.Add(this.labelTo);
            this.Controls.Add(this.textBoxTransAmount);
            this.Controls.Add(this.labelTransAmount);
            this.Controls.Add(this.textBoxAccNo);
            this.Controls.Add(this.textBoxTransNo);
            this.Controls.Add(this.labelTransNo);
            this.Controls.Add(this.labelTRANSACTIONS);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.comboBoxFromAcc);
            this.Controls.Add(this.labelFrom);
            this.Controls.Add(this.labelListAcc);
            this.Controls.Add(this.listViewAccounts);
            this.Controls.Add(this.textBoxAccBalance);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.textBoxAccYear);
            this.Controls.Add(this.textBoxAccDay);
            this.Controls.Add(this.textBoxAccMonth);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.comboBoxAccType);
            this.Controls.Add(this.textBoxAccPin);
            this.Controls.Add(this.txtAccountNum);
            this.Controls.Add(this.labelAccBalance);
            this.Controls.Add(this.labelOpenDate);
            this.Controls.Add(this.labelAccType);
            this.Controls.Add(this.labelAccPin);
            this.Controls.Add(this.labelAccNo);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.textBoxBYear);
            this.Controls.Add(this.textBoxBDay);
            this.Controls.Add(this.textBoxBMonth);
            this.Controls.Add(this.textBoxStrName);
            this.Controls.Add(this.textBoxZipCode);
            this.Controls.Add(this.textBoxCountry);
            this.Controls.Add(this.textBoxProvince);
            this.Controls.Add(this.textBoxCity);
            this.Controls.Add(this.textBoxApp);
            this.Controls.Add(this.textBoxStrNum);
            this.Controls.Add(this.textBoxPhone);
            this.Controls.Add(this.textBoxEmail);
            this.Controls.Add(this.textBoxPinCus);
            this.Controls.Add(this.textBoxLn);
            this.Controls.Add(this.textBoxFn);
            this.Controls.Add(this.textBoxId);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.labelBDay);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.labelAddress);
            this.Controls.Add(this.labelPhone);
            this.Controls.Add(this.labelEmail);
            this.Controls.Add(this.labelPin);
            this.Controls.Add(this.labelLn);
            this.Controls.Add(this.labelFn);
            this.Controls.Add(this.labelId);
            this.DoubleBuffered = true;
            this.Name = "CustomerForm";
            this.Text = "Customer Form";
            this.Load += new System.EventHandler(this.CustomerForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxBYear;
        private System.Windows.Forms.TextBox textBoxBDay;
        private System.Windows.Forms.TextBox textBoxBMonth;
        private System.Windows.Forms.TextBox textBoxStrName;
        private System.Windows.Forms.TextBox textBoxZipCode;
        private System.Windows.Forms.TextBox textBoxCountry;
        private System.Windows.Forms.TextBox textBoxProvince;
        private System.Windows.Forms.TextBox textBoxCity;
        private System.Windows.Forms.TextBox textBoxApp;
        private System.Windows.Forms.TextBox textBoxStrNum;
        private System.Windows.Forms.TextBox textBoxPhone;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.TextBox textBoxPinCus;
        private System.Windows.Forms.TextBox textBoxLn;
        private System.Windows.Forms.TextBox textBoxFn;
        private System.Windows.Forms.TextBox textBoxId;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label labelBDay;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label labelAddress;
        private System.Windows.Forms.Label labelPhone;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.Label labelPin;
        private System.Windows.Forms.Label labelLn;
        private System.Windows.Forms.Label labelFn;
        private System.Windows.Forms.Label labelId;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox comboBoxAccType;
        private System.Windows.Forms.TextBox textBoxAccPin;
        private System.Windows.Forms.TextBox txtAccountNum;
        private System.Windows.Forms.Label labelAccBalance;
        private System.Windows.Forms.Label labelOpenDate;
        private System.Windows.Forms.Label labelAccType;
        private System.Windows.Forms.Label labelAccPin;
        private System.Windows.Forms.Label labelAccNo;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBoxAccYear;
        private System.Windows.Forms.TextBox textBoxAccDay;
        private System.Windows.Forms.TextBox textBoxAccMonth;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox textBoxAccBalance;
        private System.Windows.Forms.Label labelListAcc;
        private System.Windows.Forms.ListView listViewAccounts;
        private System.Windows.Forms.ColumnHeader lstAccNumber;
        private System.Windows.Forms.ColumnHeader lstAcPin;
        private System.Windows.Forms.ColumnHeader lstAcType;
        private System.Windows.Forms.ColumnHeader lstOpenDate;
        private System.Windows.Forms.ColumnHeader lstAcBalance;
        private System.Windows.Forms.ColumnHeader lstAccTrans;
        private System.Windows.Forms.ComboBox comboBoxFromAcc;
        private System.Windows.Forms.Label labelFrom;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label labelTRANSACTIONS;
        private System.Windows.Forms.TextBox textBoxTransNo;
        private System.Windows.Forms.Label labelTransNo;
        private System.Windows.Forms.TextBox textBoxAccNo;
        private System.Windows.Forms.TextBox textBoxTransAmount;
        private System.Windows.Forms.Label labelTransAmount;
        private System.Windows.Forms.Label labelTo;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.ComboBox comboBoxToAcc;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBoxTransYear;
        private System.Windows.Forms.TextBox textBoxTransDay;
        private System.Windows.Forms.TextBox textBoxTransMonth;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label labelTransDate;
        private System.Windows.Forms.TextBox textBoxTransBalance;
        private System.Windows.Forms.Label labelTransBalance;
        private System.Windows.Forms.ComboBox comboBoxTransType;
        private System.Windows.Forms.Label labelTransType;
        private System.Windows.Forms.TextBox textBoxTransDesc;
        private System.Windows.Forms.Label labelDesc;
        private System.Windows.Forms.Label labelListTrans;
        private System.Windows.Forms.ListView listViewTransactions;
        private System.Windows.Forms.ColumnHeader columnHeaderTransNo;
        private System.Windows.Forms.ColumnHeader columnTransDesc;
        private System.Windows.Forms.ColumnHeader columnHeaderTransDate;
        private System.Windows.Forms.ColumnHeader columnHeaderTransAmount;
        private System.Windows.Forms.ColumnHeader columnHeaderFromAcc;
        private System.Windows.Forms.ColumnHeader columnHeaderTransType;
        private System.Windows.Forms.Button buttonModify;
        private System.Windows.Forms.Button buttonConfSave;
        private System.Windows.Forms.Button buttonAddThisAcc;
        private System.Windows.Forms.Button buttonReset;
        private System.Windows.Forms.Button buttonSaveFile;
        private System.Windows.Forms.Button buttonCreateAcc;
        private System.Windows.Forms.Button buttonTransaction;
        private System.Windows.Forms.ComboBox cboCredCateg;
        private System.Windows.Forms.ComboBox comboBoxCredType;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label labelCredType;
        private System.Windows.Forms.ComboBox comboBoxSavingType;
        private System.Windows.Forms.Label labelSavingsType;
        private System.Windows.Forms.ComboBox comboBoxCheckingType;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBoxCreditCategory;
        private System.Windows.Forms.Label labelCredCategory;
        private System.Windows.Forms.Button buttonDisplayTrans;
        private System.Windows.Forms.Button buttonDisplayAcc;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonSaveTransToFile;
    }
}

