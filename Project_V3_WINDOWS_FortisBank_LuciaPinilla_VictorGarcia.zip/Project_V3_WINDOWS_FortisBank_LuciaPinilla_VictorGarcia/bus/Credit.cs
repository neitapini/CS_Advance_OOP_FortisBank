﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.bus
{
    [Serializable]
    public class Credit : Account
    {
        private double annualFees;
        private const double intRate = Rates.creditAccount;
        private EnumCreditType creditType;
        private EnumCreditCategory creditCategory;

        public double AnnualFees
        {
            get => annualFees;
            set
            {
                //Set a annualFees of 0 dolars for a no fee credit card
                if (creditCategory == EnumCreditCategory.no_fee)
                { annualFees = 0; }
                //Set a annualFees of 25 dolars for a sudente credit card
                else if (creditCategory == EnumCreditCategory.student)
                { annualFees = 25; }
                //Set a annualFees of 60 dolars for a travel credit card
                else if (creditCategory == EnumCreditCategory.travel)
                { annualFees = 60; }
                //Set a annualFees of 40 dolars for a travel credit card
                else if (creditCategory == EnumCreditCategory.cash_back)
                { annualFees = 40; }
                //Set a annualFees of 69 dolars for a business credit card
                else if (creditCategory == EnumCreditCategory.business)
                { annualFees = 69; }
            }
        }

        //public double IntRate { get => intRate; set => intRate = value; }
        public EnumCreditType CreditType { get => creditType; set => creditType = value; }
        public EnumCreditCategory CreditCategory { get => creditCategory; set => creditCategory = value; }

        public Credit()
        {
            this.AnnualFees = 0.0;
            //this.IntRate = 0.0;
            this.CreditType = EnumCreditType.undefinde;
            this.CreditCategory = EnumCreditCategory.undefinde;
        }
        public Credit(double annualFees, double intRate)
        {
            this.AnnualFees = annualFees;
            //this.IntRate = intRate;
        }
        public Credit(double annualFees, double intRate, EnumCreditType creditType, EnumCreditCategory creditCategory)
        {
            this.AnnualFees = annualFees;
            //this.IntRate = intRate;
            this.CreditType = creditType;
            this.CreditCategory = creditCategory;
        }
        override
        public String ToString()
        {
            return base.ToString() + " - " + this.AnnualFees + " - " + this.CreditType + " - " + this.CreditCategory;
        }
        override
        public double MakeTransaction()
        {
            Transaction aTrans = new Transaction();
            //The intRate for withdraws is 24% annual
            if (base.TransType == EnumTransType.withdraw)
            {
                return base.AvailableBalance - (intRate * aTrans.Amount);
            }
            //The intRate for transfers is 9% annual
            if (base.TransType == EnumTransType.transfer)
            {
                return base.AvailableBalance - (intRate * aTrans.Amount);
            }
            //The intRate for purchases is 19% annual
            else if (base.TransType == EnumTransType.payment)
            {
                return base.AvailableBalance - (intRate * aTrans.Amount);
            }
            else if (base.TransType == EnumTransType.deposit)
            {
                return base.AvailableBalance + aTrans.Amount;
            }
            else
            {
                return base.AvailableBalance;
            }

        }
    }
}
