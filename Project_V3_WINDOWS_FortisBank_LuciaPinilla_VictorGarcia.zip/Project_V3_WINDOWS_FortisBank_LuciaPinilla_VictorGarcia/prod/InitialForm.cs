﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.prod
{
    public partial class InitialForm : Form
    {
        public InitialForm()
        {
            InitializeComponent();
        }

        private void buttonManager_Click(object sender, EventArgs e)
        {
            FortisBankForm myMainFormManager = new FortisBankForm();
            myMainFormManager.ShowDialog();
        }

        private void buttonCustomer_Click(object sender, EventArgs e)
        {
            Login myMainFormCustomer = new Login();
            myMainFormCustomer.ShowDialog();
        }
    }
}
