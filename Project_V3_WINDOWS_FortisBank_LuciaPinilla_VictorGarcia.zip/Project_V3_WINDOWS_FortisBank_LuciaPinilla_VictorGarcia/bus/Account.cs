﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.bus
{
    [Serializable]
    public abstract class Account : DataAccess, ITransactionStrategy
    {
        private long accNumber;
        private int accPin;
        private EnumAccType accountType;
        private Date openDate;
        private double availableBalance;
        private EnumTransType transType;
        //private double amount;
        private List<Transaction> myTranssList;

        public long AccNumber
        {
            get { return accNumber; }
            set
            {
                if (value.Equals(""))
                {
                    FormatException fe = new FormatException();
                    throw (fe);
                }
                else if (value < 0)
                {
                    ValidateNegativeNumber e = new ValidateNegativeNumber("The input is a negative value, please enter a positive value");
                    throw (e);
                }

                accNumber = value;
            }

        }
        public int AccPin
        {
            get { return accPin; }
            set
            {
                if (value.Equals(""))
                {
                    FormatException fe = new FormatException();
                    throw (fe);
                }

                accPin = value;
            }


        }
        public EnumAccType AccountType { get => accountType; set => accountType = value; }
        public Date OpenDate { get => openDate; set => openDate = value; }
        public double AvailableBalance { get => availableBalance; set => availableBalance = value; }
        public List<Transaction> MyTranssList { get => myTranssList; set => myTranssList = value; }
        public EnumTransType TransType { get => transType; set => transType = value; }
        //public double Amount { get => amount; set => amount = value; }


        public Account()
        {
            this.AccNumber = 000000;
            this.AccPin = 0000;
            this.AccountType = EnumAccType.undefined;
            this.OpenDate = new Date(00, 00, 00000);
            this.AvailableBalance = 0.0;
            this.TransType = EnumTransType.undefined;
            //this.Amount = 0.0;
            this.MyTranssList = new List<Transaction>();

        }

        public Account(long accNumber, int pin, EnumAccType accountType, Date openDate, double availableBalance, List<Transaction> myTranssList)
        {
            this.AccNumber = accNumber;
            this.AccPin = accPin;
            this.AccountType = accountType;
            this.OpenDate = openDate;
            this.AvailableBalance = availableBalance;
            this.MyTranssList = myTranssList;

        }
        public Account(long accNumber, int pin, EnumAccType accountType, Date openDate, double availableBalance, EnumTransType transType, List<Transaction> myTranssList)
        {
            this.AccNumber = accNumber;
            this.AccPin = accPin;
            this.AccountType = accountType;
            this.OpenDate = openDate;
            this.AvailableBalance = availableBalance;
            this.TransType = transType;
            this.MyTranssList = myTranssList;

        }
        public Account(long accNumber, int pin, EnumAccType accountType, Date openDate, double availableBalance, EnumTransType transType, double amount, List<Transaction> myTranssList)
        {
            this.AccNumber = accNumber;
            this.AccPin = accPin;
            this.AccountType = accountType;
            this.OpenDate = openDate;
            this.AvailableBalance = availableBalance;
            this.TransType = transType;
            //this.Amount = amount;
            this.MyTranssList = myTranssList;

        }
        override
        public String ToString()
        {
            return this.AccNumber + " - " +
                    this.AccPin + " - " +
                    this.AccountType + " - " +
                    this.OpenDate + " - " +
                    this.AvailableBalance + " - " +
                    this.TransType;
            //this.MyTranssList;
        }
        public abstract double MakeTransaction();


    }
}
