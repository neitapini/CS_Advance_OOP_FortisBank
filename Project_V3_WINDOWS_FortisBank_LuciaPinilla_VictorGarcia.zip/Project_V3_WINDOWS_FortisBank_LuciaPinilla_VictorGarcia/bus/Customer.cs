﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.bus
{
    [Serializable]
    public class Customer
    {
        private int id;
        private String fn;
        private String ln;
        private int pin;
        private String email;
        private String phone;
        private Address address;
        private Date birthDate;
        private List<Account> myAccounts = new List<Account>();

        public int Id
        {
            get { return id; }
            set
            {
                if (value.Equals(""))
                {
                    FormatException fe = new FormatException();
                    throw (fe);
                }

                id = value;
            }
        }
        public string Fn
        {
            get { return fn; }
            set
            {

                if (value.Equals("") || IsNumber(value))
                {
                    Exception ex = new Exception();
                    throw (ex);
                }

                fn = value;
            }
        }
        public string Ln
        {
            get { return ln; }
            set
            {

                if (value.Equals("") || IsNumber(value))
                {
                    Exception ex = new Exception();
                    throw (ex);
                }

                ln = value;
            }

        }
        public int Pin
        {
            get { return pin; }
            set
            {
                if (value.Equals(""))
                {
                    FormatException fe = new FormatException();
                    throw (fe);
                }

                pin = value;
            }
        }
        public string Email { get => email; set => email = value; }
        public string Phone { get => phone; set => phone = value; }
        public Address Address { get => address; set => address = value; }
        public Date BirthDate { get => birthDate; set => birthDate = value; }
        public List<Account> MyAccounts { get => myAccounts; set => myAccounts = value; }

        public Customer()
        {

            this.Id = 0000;
            this.Fn = "unknown";
            this.Pin = 0000;
            this.Email = "unknown";
            this.Phone = "unknown";
            this.Address = new Address(0000, "unknown", 0000, "unknown", "unknown", "unknown", "unknown");
            this.BirthDate = new Date(00, 00, 0000);
            this.MyAccounts = new List<Account>();

        }
        public Customer(int id, String fn, String ln, int pin, String email, String phone, Address address, Date birthDate, List<Account> myAccounts)
        {
            this.Id = id;
            this.Fn = fn;
            this.Pin = pin;
            this.Email = email;
            this.Phone = phone;
            this.Address = address;
            this.BirthDate = birthDate;
            this.MyAccounts = myAccounts;
        }
        override
        public String ToString()
        {
            return this.Id + " - " +
                    this.Fn + " - " +
                    this.Pin + " - " +
                    this.Email + " - " +
                    this.Phone + " - " +
                    this.Address + " - " +
                    this.BirthDate;
            //this.MyAccounts;
        }
        public Savings OpenSavingsAccount(EnumAccType type)
        {
            if (type == EnumAccType.savings)
            {
                Savings mySavingsAccount = new Savings();
                return mySavingsAccount;
            }
            else if (type == EnumAccType.currency)
            {
                Savings mySavingsCurrencyAcc = new Savings();
                return mySavingsCurrencyAcc;
            }
            else
            {
                return null;
            }
        }
        public Credit OpenCreditAccount(EnumAccType type)
        {
            if (type == EnumAccType.credit)
            {
                Credit myCreditAccount = new Credit();
                return myCreditAccount;
            }
            else
            {
                return null;
            }
        }
        public bool IsNumber(String value)
        {
            // bool valid = false;
            int cpt = 0;
            for (int j = 0; j < value.Length; j++)
            {
                //Prenom invalid
                if (!Char.IsLetter(value, j)) //&& (!char.IsWhiteSpace(value, j))
                    cpt++;
            }
            if (cpt > 0)
                return true;
            else return false;

        }

    }
}
