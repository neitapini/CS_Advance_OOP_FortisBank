﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.bus;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;


namespace Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.prod
{
    public partial class Login : Form
    {
        static String binFileCustomer = @"../../data/Bikes.bin";
        DataAccess myColFromFile = new DataAccess();

        public Login()
        {
            InitializeComponent();
        }
        private void ValidateDigit(KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar))
            {

                MessageBox.Show("Must be a digit only");
                e.Handled = true;

            }
        }

        private void Login_Load(object sender, EventArgs e)
        {
            this.textBoxLoginId.Focus();
            if (File.Exists(binFileCustomer))
            {
                FileStream fs = new FileStream(binFileCustomer, FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                myColFromFile.CustomersList = (List<Customer>)bin.Deserialize(fs);

                fs.Close();
            }
            else
            {
                MessageBox.Show("The collection is empty");
            }


        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            

            //ID 1, PIN 1234
            foreach (Customer element in myColFromFile.CustomersList)
            {

                if (element.Id == Convert.ToInt32(textBoxLoginId.Text) && element.Pin == Convert.ToInt32(textBoxLoginPass.Text))
                {
                    CustomerForm myMainForm = new CustomerForm();
                    myMainForm.ShowDialog();
                    break;
                }
                else
                {
                    MessageBox.Show("Wrong Id or PIN");
                    
                }
                

            }
            foreach (Control myControl in Controls)
            {
                if (myControl is TextBox)
                {
                    myControl.Text = "";
                }
            }

        }

        private void textBoxLoginPass_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateDigit(e);
        }

        private void textBoxLoginId_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidateDigit(e);
        }
    }
}
