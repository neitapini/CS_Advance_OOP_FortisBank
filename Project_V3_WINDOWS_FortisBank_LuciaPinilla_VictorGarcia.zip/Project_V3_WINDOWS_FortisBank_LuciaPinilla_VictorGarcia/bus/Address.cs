﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.bus
{
    [Serializable]
    public class Address
    {
        private int strNum;
        private String strName;
        private int aptNum;
        private String city;
        private String province;
        private String zipCode;
        private String country;

        public int StrNum
        {
            get { return strNum; }
            set
            {
                if (value.Equals(""))
                {
                    FormatException fe = new FormatException();
                    throw (fe);
                }
                else if (value < 0)
                {
                    ValidateNegativeNumber e = new ValidateNegativeNumber("The input is a negative value, please enter a positive value");
                    throw (e);
                }

                strNum = value;
            }
        }
        public string StrName
        {
            get { return strName; }
            set
            {

                if (value.Equals("") || IsNumber(value))
                {
                    Exception ex = new Exception();
                    throw (ex);
                }

                strName = value;
            }
        }
        public int AptNum
        {
            get { return aptNum; }
            set
            {
                if (value.Equals(""))
                {
                    FormatException fe = new FormatException();
                    throw (fe);
                }
                else if (value < 0)
                {
                    ValidateNegativeNumber e = new ValidateNegativeNumber("The input is a negative value, please enter a positive value");
                    throw (e);
                }

                aptNum = value;
            }
        }
        public string City
        {
            get { return city; }
            set
            {

                if (value.Equals("") || IsNumber(value))
                {
                    Exception ex = new Exception();
                    throw (ex);
                }

                city = value;
            }
        }
        public string Province { get => province; set => province = value; }
        public string ZipCode { get => zipCode; set => zipCode = value; }
        public string Country { get => country; set => country = value; }

        public Address()
        {
            this.StrNum = 0000;
            this.StrName = "unknown";
            this.AptNum = 0000;
            this.City = "unknown";
            this.Province = "unknown";
            this.ZipCode = "unknown";
            this.Country = "unknown";

        }

        public Address(int strNum, String strName, int aptNum, String city, String province, String zipCode, String country)
        {
            this.StrNum = strNum;
            this.StrName = strName;
            this.AptNum = aptNum;
            this.City = city;
            this.Province = province;
            this.ZipCode = zipCode;
            this.Country = country;
        }
        override
        public String ToString()
        {
            return this.StrNum + " " +
                    this.StrName + " " +
                    this.AptNum + " " +
                    this.City + " " +
                    this.Province + " " +
                    this.ZipCode + " " +
                    this.Country;
        }
        public bool IsNumber(String value)
        {
            // bool valid = false;
            int cpt = 0;
            for (int j = 0; j < value.Length; j++)
            {
                //Prenom invalid
                if (!Char.IsLetter(value, j)) //&& (!char.IsWhiteSpace(value, j))
                    cpt++;
            }
            if (cpt > 0)
                return true;
            else return false;

        }
    }
}
