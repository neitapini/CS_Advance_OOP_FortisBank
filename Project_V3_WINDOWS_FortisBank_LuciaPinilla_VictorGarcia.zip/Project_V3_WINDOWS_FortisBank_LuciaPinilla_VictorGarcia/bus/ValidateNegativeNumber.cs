﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.bus
{
    public class ValidateNegativeNumber : Exception
    {
        private static String msg = "Invalid Month Value Exception";
        public ValidateNegativeNumber() : base(msg)
        { }

        public ValidateNegativeNumber(String aMsg) : base(aMsg)
        { }
    }
}
