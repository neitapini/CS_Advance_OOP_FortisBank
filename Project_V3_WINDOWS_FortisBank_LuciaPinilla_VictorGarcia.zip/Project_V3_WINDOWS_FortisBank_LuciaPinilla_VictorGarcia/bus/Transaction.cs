﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.bus
{
    [Serializable]
    public class Transaction
    {
        private long transNumber;
        private String description;
        private Date transDate;
        private double amount;
        private long accountNumber;
        private EnumTransType transType;

        public long TransNumber { get => transNumber; set => transNumber = value; }
        public string Description { get => description; set => description = value; }
        public Date TransDate { get => transDate; set => transDate = value; }
        public double Amount
        {
            get { return amount; }
            set
            {
                if (value.Equals(""))
                {
                    FormatException fe = new FormatException();
                    throw (fe);
                }
                else if (value < 0)
                {
                    ValidateNegativeNumber e = new ValidateNegativeNumber("The input is a negative value, please enter a positive value");
                    throw (e);
                }
                amount = value;
            }
        }
        public EnumTransType TransType { get => transType; set => transType = value; }

        public long AccountNumber { get => accountNumber; set => accountNumber = value; }

        public Transaction()
        {
            this.TransNumber = 000000;
            this.Description = "unknown";
            this.TransDate = new Date(00, 00, 0000);
            this.Amount = 0.0;
            this.TransType = EnumTransType.undefined;
            this.AccountNumber = 0000000;
            
        }
        public Transaction(long transNumber, String description, Date transDate, double amount, EnumTransType transType)
        {
            this.TransNumber = transNumber;
            this.Description = description;
            this.TransDate = transDate;
            this.Amount = amount;
            this.TransType = transType;
        }
        public Transaction(long transNumber, String description, Date transDate, double amount, EnumTransType transType, long accountNumber)
        {
            this.TransNumber = transNumber;
            this.Description = description;
            this.TransDate = transDate;
            this.Amount = amount;
            this.TransType = transType;
            this.AccountNumber = accountNumber;
        }
        override
        public String ToString()
        {
            return  this.TransNumber + " - " +
                    this.AccountNumber + " - " +
                    this.TransDate + " - " +
                    this.Amount + " - " +
                    this.TransType + " - " +
                    this.Description ;
        }

    }
}
