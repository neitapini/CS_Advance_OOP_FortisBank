﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.bus
{
    public class ValidateDate : Exception
    {
        private static String msg = "Invalid Date Value";
        public ValidateDate() : base(msg)
        { }

        public ValidateDate(String aMsg) : base(aMsg)
        { }
    }
}
