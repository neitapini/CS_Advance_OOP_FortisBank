﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project_V3_WINDOWS_FortisBank_LuciaPinilla_VictorGarcia.bus
{ 
    public static class Rates
    {
        private const double ActiveBaseRate = 10.25;
        private const double pasiveBaseRate = 6.55;


        public const double savingAccountRate = pasiveBaseRate + 2.5;
        public const double checkingAccoutRate = pasiveBaseRate - 6.55;
        public const double creditAccount = ActiveBaseRate + 4.55;
    }
}
